'use strict';

/* =========================================================
   BGM MIX STUDIO - renderer.js
   Casa Shindy / ダンス公演用BGMミックス編集ソフト
   ========================================================= */

const TRACK_COLORS = ['#d4a548', '#4fd1c5', '#e0605c', '#7c9fe0', '#b98be0', '#8bd17c', '#e0a97c', '#7ce0c9'];
const SNAP_SEC = 0.5;

let audioCtx = null;
const audioBufferCache = {}; // sourceId(filePath) -> AudioBuffer

const state = {
  tracks: [],           // {id,name,color,volume,pan,muted,solo,clips:[...]}
  pxPerSec: 40,
  selectedClipIds: new Set(), // 複数選択対応(旧: selectedClipId 単数)
  isPlaying: false,
  playStartCtxTime: 0,  // audioCtx.currentTime at play start
  playStartOffset: 0,   // timeline sec at play start
  activeSources: [],
  snap: true,
};

const trackGainNodes = {};  // trackId -> {gain, pan}  (live playback nodes)
let masterGain = null;

function uid() { return Math.random().toString(36).slice(2, 10); }

/* ============ Undo / Redo ============
   state.tracks はプレーンなデータ(音声バッファそのものは audioBufferCache に文字列キーで
   間接参照されているだけ)なので、JSON化したスナップショットを積むだけで安全にUndo/Redoできる。
   ただし対象は「クリップの追加・削除・移動・トリム・分割・BPM変更・ボーカル処理・ナレーション生成/更新・
   トラックの追加/削除/複製」など離散的な操作のみ。フェーダー/パン/FXスライダーやオートメーションの
   点のドラッグなど連続的な調整はカバーしていない(あえて対象外にした。正直に書いておく)。 */
const undoStack = [];
const redoStack = [];
const MAX_UNDO_STEPS = 60;

function snapshotTracks() {
  return JSON.stringify(state.tracks);
}

function pushUndo() {
  undoStack.push(snapshotTracks());
  if (undoStack.length > MAX_UNDO_STEPS) undoStack.shift();
  redoStack.length = 0; // 新しい操作をしたらredo履歴は破棄する
}

function pushUndoWithSnapshot(snapshot) {
  undoStack.push(snapshot);
  if (undoStack.length > MAX_UNDO_STEPS) undoStack.shift();
  redoStack.length = 0;
}

function undo() {
  if (undoStack.length === 0) { setStatus('これ以上元に戻せません。'); return; }
  redoStack.push(snapshotTracks());
  const prev = undoStack.pop();
  state.tracks = JSON.parse(prev);
  state.selectedClipIds.clear();
  renderAll();
  setStatus('元に戻しました。(Cmd+Shift+Z でやり直せます)');
}

function redo() {
  if (redoStack.length === 0) { setStatus('やり直せる操作がありません。'); return; }
  undoStack.push(snapshotTracks());
  const next = redoStack.pop();
  state.tracks = JSON.parse(next);
  state.selectedClipIds.clear();
  renderAll();
  setStatus('やり直しました。');
}

function getAudioCtx() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    masterGain = audioCtx.createGain();
    masterGain.gain.value = 1.0;
    masterGain.connect(audioCtx.destination);
  }
  return audioCtx;
}

function fmtTime(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const m = Math.floor(sec / 60);
  const s = sec - m * 60;
  return `${String(m).padStart(2, '0')}:${s.toFixed(1).padStart(4, '0')}`;
}

function base64ToArrayBuffer(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

function getTotalDuration() {
  let max = 0;
  state.tracks.forEach(t => t.clips.forEach(c => {
    max = Math.max(max, c.start + c.duration);
  }));
  return max;
}

function getMaxTrackEnd() {
  // 新規インポートを末尾に連結配置するための現在の最終時刻
  return getTotalDuration();
}

/* ============ インポート (ファイルダイアログ / ドラッグ&ドロップ共通) ============ */

async function addAudioFileToTimeline(fileName, filePath, arrayBuffer, appendAt) {
  setStatus(`${fileName} を解析中...`);
  // decodeAudioData はArrayBufferを消費(detach)するのでコピーを渡す
  const buffer = await getAudioCtx().decodeAudioData(arrayBuffer.slice(0));
  audioBufferCache[filePath] = buffer;

  setStatus(`${fileName} のBPMを測定中...`);
  const bpmResult = await detectBpmForBuffer(buffer);

  const track = createTrack(fileName.replace(/\.[^/.]+$/, ''));
  const clip = {
    id: uid(),
    sourceId: filePath,
    playSourceId: filePath, // 実際の再生/波形描画に使うバッファのキー(BPM変更時に切替)
    filePath,
    fileName,
    start: appendAt,
    offset: 0,
    duration: buffer.duration,
    sourceDuration: buffer.duration,
    fadeIn: 0,
    fadeOut: 0,
    detectedBpm: bpmResult ? bpmResult.bpm : null,
    bpmConfidence: bpmResult ? bpmResult.confidence : 0,
    targetBpm: bpmResult ? bpmResult.bpm : null, // 未変更時は検出値=目標値(ストレッチなし)
  };
  track.clips.push(clip);
  pushUndo();
  state.tracks.push(track);
  renderAll();
  return appendAt + buffer.duration;
}

async function handleImport() {
  const files = await window.electronAPI.importAudioFiles();
  if (!files || files.length === 0) return;

  let appendAt = getMaxTrackEnd();
  let okCount = 0;
  for (const f of files) {
    try {
      const arrayBuffer = base64ToArrayBuffer(f.base64);
      appendAt = await addAudioFileToTimeline(f.fileName, f.filePath, arrayBuffer, appendAt);
      okCount++;
    } catch (err) {
      console.error('decode failed', f.fileName, err);
      setStatus(`⚠ ${f.fileName} の読み込みに失敗しました`);
    }
  }
  renderAll();
  setStatus(`${okCount}件を追加しました。BPMは自動測定(低音のビート検出方式・目安値)。合わない場合は右クリックで手動修正できる。`);
}

const AUDIO_EXT_RE = /\.(mp3|wav|wave|aac|m4a|ogg|oga|flac|aif|aiff)$/i;

async function handleFileDrop(e) {
  e.preventDefault();
  document.body.classList.remove('drag-active');
  const dropped = Array.from(e.dataTransfer.files || []).filter(f => AUDIO_EXT_RE.test(f.name));
  if (dropped.length === 0) {
    setStatus('音声ファイル(mp3/wav/aac/m4a/ogg/flac/aiff)をドロップしてください。');
    return;
  }

  let appendAt = getMaxTrackEnd();
  let okCount = 0;
  for (const file of dropped) {
    try {
      const arrayBuffer = await file.arrayBuffer();
      // Electronはドロップされたファイルに実ファイルパス(.path)を付与する。
      // これがないと後でプロジェクト保存→再読込した時に音源を再ロードできないので必須。
      const filePath = file.path || null;
      if (!filePath) {
        setStatus(`⚠ ${file.name}: ファイルパスを取得できませんでした(この環境では未対応の可能性)`);
        continue;
      }
      appendAt = await addAudioFileToTimeline(file.name, filePath, arrayBuffer, appendAt);
      okCount++;
    } catch (err) {
      console.error('drop import failed', file.name, err);
      setStatus(`⚠ ${file.name} の読み込みに失敗しました`);
    }
  }
  renderAll();
  if (okCount > 0) setStatus(`ドラッグ&ドロップで${okCount}件を追加しました。`);
}

function initDragDrop() {
  ['dragenter', 'dragover'].forEach(evt => {
    document.addEventListener(evt, (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.dataTransfer && Array.from(e.dataTransfer.items || []).some(it => it.kind === 'file')) {
        document.body.classList.add('drag-active');
      }
    });
  });
  document.addEventListener('dragleave', (e) => {
    if (e.target === document.documentElement || e.target === document.body) {
      document.body.classList.remove('drag-active');
    }
  });
  document.addEventListener('drop', handleFileDrop);
}

function getClipBuffer(clip) {
  return audioBufferCache[clip.playSourceId || clip.sourceId];
}

function createDefaultEffects() {
  return {
    delay: { enabled: false, timeSec: 0.3, feedback: 0.35, mix: 0.3 },
    filter: { enabled: false, type: 'lowpass', freq: 8000, mix: 1.0 },
    reverb: { enabled: false, mix: 0.25, size: 2.2 },
    ring: { enabled: false, freq: 150, mix: 0.6 }, // リングモジュレーター(宇宙人/ロボット声)
  };
}

// 旧バージョンのプロジェクトファイル(ring等のフィールドが無い)を読み込んでも安全に動くようマージする
function normalizeEffects(saved) {
  const d = createDefaultEffects();
  if (!saved) return d;
  return {
    delay: { ...d.delay, ...(saved.delay || {}) },
    filter: { ...d.filter, ...(saved.filter || {}) },
    reverb: { ...d.reverb, ...(saved.reverb || {}) },
    ring: { ...d.ring, ...(saved.ring || {}) },
  };
}

function createTrack(name) {
  const color = TRACK_COLORS[state.tracks.length % TRACK_COLORS.length];
  const track = {
    id: uid(),
    name: name || `トラック${state.tracks.length + 1}`,
    color,
    volume: 0.85,
    pan: 0,
    muted: false,
    solo: false,
    clips: [],
    effects: createDefaultEffects(),
    automation: { volume: [], pan: [] }, // {t: 秒, v: 値} のブレイクポイント配列(時間順)
    automationMode: null, // null | 'volume' | 'pan' — このトラックで現在表示中のオートメーションレーン
  };
  return track;
}

// 旧プロジェクトファイル(automationフィールドが無い)を安全に読み込むためのフォールバック
function normalizeAutomation(saved) {
  if (!saved) return { volume: [], pan: [] };
  return {
    volume: Array.isArray(saved.volume) ? saved.volume.slice().sort((a, b) => a.t - b.t) : [],
    pan: Array.isArray(saved.pan) ? saved.pan.slice().sort((a, b) => a.t - b.t) : [],
  };
}

// タイムライン時刻 t における自動化パラメータの値を線形補間で取得
function automationValueAt(breakpoints, t, fallback) {
  if (!breakpoints || breakpoints.length === 0) return fallback;
  if (t <= breakpoints[0].t) return breakpoints[0].v;
  const last = breakpoints[breakpoints.length - 1];
  if (t >= last.t) return last.v;
  for (let i = 0; i < breakpoints.length - 1; i++) {
    const a = breakpoints[i], b = breakpoints[i + 1];
    if (t >= a.t && t <= b.t) {
      const ratio = (b.t - a.t) < 1e-9 ? 0 : (t - a.t) / (b.t - a.t);
      return a.v + (b.v - a.v) * ratio;
    }
  }
  return last.v;
}

// AudioParamに対して、fromTimelineTime以降のブレイクポイントをスケジュールする。
// (クリップのフェード処理 scheduleClipEnvelope と同じ考え方をトラック全体に一般化したもの)
function scheduleAutomationParam(audioParam, breakpoints, staticValue, whenCtx, fromTimelineTime) {
  if (!breakpoints || breakpoints.length === 0) {
    audioParam.setValueAtTime(staticValue, whenCtx);
    return;
  }
  const startVal = automationValueAt(breakpoints, fromTimelineTime, staticValue);
  audioParam.cancelScheduledValues(whenCtx);
  audioParam.setValueAtTime(startVal, whenCtx);
  breakpoints.filter(bp => bp.t > fromTimelineTime).forEach(bp => {
    const delay = bp.t - fromTimelineTime;
    audioParam.linearRampToValueAtTime(bp.v, whenCtx + delay);
  });
}

function deleteTrack(trackId) {
  pushUndo();
  state.tracks = state.tracks.filter(t => t.id !== trackId);
  renderAll();
}

function addEmptyTrack() {
  pushUndo();
  const track = createTrack(`トラック${state.tracks.length + 1}`);
  state.tracks.push(track);
  renderAll();
  setStatus('空のトラックを追加しました。クリップをこのトラックに追加してください。');
}

function duplicateTrack(trackId) {
  const track = state.tracks.find(t => t.id === trackId);
  if (!track) return;
  pushUndo();
  const idx = state.tracks.indexOf(track);
  const newTrack = {
    ...track,
    id: uid(),
    name: track.name + ' コピー',
    effects: JSON.parse(JSON.stringify(track.effects)), // 深いコピー(参照共有を避ける)
    automation: JSON.parse(JSON.stringify(ensureTrackAutomation(track))), // 同様に深いコピー
    automationMode: null,
    clips: track.clips.map(c => ({ ...c, id: uid() })), // クリップも新しいidで複製(音声バッファは共有)
  };
  state.tracks.splice(idx + 1, 0, newTrack); // 元のすぐ下の段に挿入
  renderAll();
  setStatus(`「${track.name}」をトラックごと複製しました。`);
}

/* ============ 描画: ヘッダー / ルーラー / トラックレーン ============ */

function renderAll() {
  document.documentElement.style.setProperty('--px-per-sec', state.pxPerSec + 'px');
  renderTrackHeaders();
  renderRuler();
  renderTracksContainer();
  updateTimeDisplay();
}

function renderTrackHeaders() {
  const container = document.getElementById('trackHeaders');
  container.querySelectorAll('.track-header').forEach(el => el.remove());

  state.tracks.forEach(track => {
    const el = document.createElement('div');
    el.className = 'track-header';
    el.innerHTML = `
      <div class="track-header-top">
        <span class="track-grip" data-track="${track.id}" title="ドラッグでトラックの順番を変更">⠿</span>
        <span class="track-color-dot" style="background:${track.color}"></span>
        <input class="track-name" value="${escapeHtml(track.name)}" data-track="${track.id}" />
        <span class="track-duplicate" data-track="${track.id}" title="トラックを複製(すぐ下に追加)">⧉</span>
        <span class="track-delete" data-track="${track.id}" title="トラック削除">✕</span>
      </div>
      <div class="track-controls">
        <button class="track-btn ${track.muted ? 'active-mute' : ''}" data-action="mute" data-track="${track.id}">M</button>
        <button class="track-btn ${track.solo ? 'active-solo' : ''}" data-action="solo" data-track="${track.id}">S</button>
        <input type="range" class="track-fader" min="0" max="1.2" step="0.01" value="${track.volume}" data-track="${track.id}" title="音量" />
      </div>
      <div class="track-mini-row">
        <span>PAN</span>
        <input type="range" class="track-pan" min="-1" max="1" step="0.01" value="${track.pan}" data-track="${track.id}" />
      </div>
      <div class="track-mini-row bpm-fx-row">
        <span>BPM</span>
        <input type="number" class="track-bpm-input" min="40" max="300" step="1"
          value="${trackDisplayBpm(track) || ''}" placeholder="―" data-track="${track.id}"
          title="Enterキーで確定: このトラックの全クリップのテンポを変更(ピッチはそのまま)" />
        <button class="track-btn track-auto-btn ${track.automationMode ? 'active-auto' : ''}" data-action="auto" data-track="${track.id}" title="オートメーション表示切替(音量/パンの時間変化を編集)">${track.automationMode === 'volume' ? 'VOL' : track.automationMode === 'pan' ? 'PAN' : '〜'}</button>
        <button class="track-btn track-fx-btn ${trackHasActiveFx(track) ? 'active-fx' : ''}" data-action="fx" data-track="${track.id}" title="エフェクト(ディレイ/フィルター/リバーブ)">FX</button>
      </div>
    `;
    container.appendChild(el);
  });

  container.querySelectorAll('.track-name').forEach(inp => {
    inp.addEventListener('change', e => {
      const t = state.tracks.find(t => t.id === e.target.dataset.track);
      if (t) t.name = e.target.value;
    });
  });
  container.querySelectorAll('.track-delete').forEach(el => {
    el.addEventListener('click', e => deleteTrack(e.target.dataset.track));
  });
  container.querySelectorAll('.track-duplicate').forEach(el => {
    el.addEventListener('click', e => duplicateTrack(e.target.dataset.track));
  });
  container.querySelectorAll('[data-action="mute"]').forEach(btn => {
    btn.addEventListener('click', e => {
      const t = state.tracks.find(t => t.id === e.target.dataset.track);
      t.muted = !t.muted;
      applyLiveMixState();
      renderTrackHeaders();
    });
  });
  container.querySelectorAll('[data-action="solo"]').forEach(btn => {
    btn.addEventListener('click', e => {
      const t = state.tracks.find(t => t.id === e.target.dataset.track);
      t.solo = !t.solo;
      applyLiveMixState();
      renderTrackHeaders();
    });
  });
  container.querySelectorAll('.track-fader').forEach(inp => {
    inp.addEventListener('input', e => {
      const t = state.tracks.find(t => t.id === e.target.dataset.track);
      t.volume = parseFloat(e.target.value);
      applyLiveMixState();
    });
  });
  container.querySelectorAll('.track-pan').forEach(inp => {
    inp.addEventListener('input', e => {
      const t = state.tracks.find(t => t.id === e.target.dataset.track);
      t.pan = parseFloat(e.target.value);
      applyLiveMixState();
    });
  });
  container.querySelectorAll('.track-bpm-input').forEach(inp => {
    const commitBpm = async () => {
      const t = state.tracks.find(t => t.id === inp.dataset.track);
      const v = parseFloat(inp.value);
      if (!t || !v || v <= 0) { renderTrackHeaders(); return; }
      const clipsWithBpm = t.clips.filter(c => c.detectedBpm);
      if (clipsWithBpm.length === 0) {
        alert('このトラックはBPM未検出のため変更できません。クリップを右クリック→「元BPMを手動設定」で先に設定してください。');
        renderTrackHeaders();
        return;
      }
      for (const clip of clipsWithBpm) await applyBpmStretch(clip, v);
      renderAll();
    };
    // Enterキーで明示的に確定した時だけBPM変更(タイムストレッチ)を実行する。
    // blur(クリックで別の場所に移動しただけ等)では変更しない — 誤操作で重い処理が走るのを防ぐため。
    inp.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); commitBpm(); inp.blur(); }
      if (e.key === 'Escape') { inp.blur(); renderTrackHeaders(); }
    });
    inp.addEventListener('blur', () => {
      const t = state.tracks.find(t => t.id === inp.dataset.track);
      const committed = t ? trackDisplayBpm(t) : null;
      if (parseFloat(inp.value) !== committed) inp.value = committed || '';
    });
  });
  container.querySelectorAll('[data-action="fx"]').forEach(btn => {
    btn.addEventListener('click', e => {
      const t = state.tracks.find(t => t.id === e.target.dataset.track);
      showTrackEffectsPanel(t, e.currentTarget);
    });
  });
  container.querySelectorAll('[data-action="auto"]').forEach(btn => {
    btn.addEventListener('click', e => {
      const t = state.tracks.find(t => t.id === e.target.dataset.track);
      // null → volume → pan → null の順でサイクル
      t.automationMode = t.automationMode === null ? 'volume' : t.automationMode === 'volume' ? 'pan' : null;
      renderAll();
    });
  });
}

function trackDisplayBpm(track) {
  const c = track.clips.find(c => c.targetBpm);
  return c ? Math.round(c.targetBpm) : null;
}

function trackHasActiveFx(track) {
  const e = track.effects;
  if (!e) return false;
  return e.delay.enabled || e.filter.enabled || e.reverb.enabled || e.ring.enabled;
}

function renderRuler() {
  const ruler = document.getElementById('ruler');
  ruler.innerHTML = '';
  const total = Math.max(getTotalDuration() + 20, 60);
  ruler.style.width = (total * state.pxPerSec) + 'px';
  const step = state.pxPerSec < 25 ? 5 : (state.pxPerSec < 60 ? 2 : 1);
  for (let s = 0; s <= total; s += step) {
    const tick = document.createElement('div');
    tick.className = 'ruler-tick' + (s % (step * 5) === 0 ? ' major' : '');
    tick.style.left = (s * state.pxPerSec) + 'px';
    if (s % (step * 5) === 0) tick.textContent = fmtTime(s);
    ruler.appendChild(tick);
  }
  // 目盛りラベルの<div>がクリックを奪って無反応になっていたバグを修正。
  // e.target のチェックはやめて、常に ruler 自身の座標を基準にクリック位置を計算する。
  ruler.onclick = (e) => {
    const rect = ruler.getBoundingClientRect();
    const t = (e.clientX - rect.left) / state.pxPerSec;
    seekTo(Math.max(0, t));
  };
}

const TRACK_LANE_HEIGHT = 118; // style.css の --track-h と一致させること(値<->Y座標変換に使う)

// track.automation が無い/壊れている場合でも安全に触れるよう、実体を保証してそのまま返す(参照はlive)
function ensureTrackAutomation(track) {
  if (!track.automation) track.automation = { volume: [], pan: [] };
  if (!Array.isArray(track.automation.volume)) track.automation.volume = [];
  if (!Array.isArray(track.automation.pan)) track.automation.pan = [];
  return track.automation;
}

// クリップが移動した時、そのクリップの範囲内にあったオートメーションの点を同じ距離だけスライドさせる。
// (オートメーションはトラック全体に紐づくデータだが、実運用では1トラック=1クリップが基本のため、
//  クリップと一緒に動かした方が直感に合う)
function shiftAutomationForClipMove(track, originalStart, duration, delta) {
  if (!delta) return;
  const auto = ensureTrackAutomation(track);
  const rangeStart = originalStart - 0.05;
  const rangeEnd = originalStart + duration + 0.05;
  ['volume', 'pan'].forEach(mode => {
    auto[mode].forEach(bp => {
      if (bp.t >= rangeStart && bp.t <= rangeEnd) {
        bp.t = Math.max(0, bp.t + delta);
      }
    });
    auto[mode].sort((a, b) => a.t - b.t);
  });
}

function automationValueToY(mode, value) {
  if (mode === 'volume') {
    const clamped = Math.max(0, Math.min(1.2, value));
    return TRACK_LANE_HEIGHT * (1 - clamped / 1.2);
  }
  const clamped = Math.max(-1, Math.min(1, value)); // pan: 上=+1(右) 下=-1(左)
  return TRACK_LANE_HEIGHT * (1 - (clamped + 1) / 2);
}

function automationYToValue(mode, y) {
  const ratio = Math.max(0, Math.min(1, y / TRACK_LANE_HEIGHT));
  if (mode === 'volume') return (1 - ratio) * 1.2;
  return (1 - ratio) * 2 - 1;
}

function renderAutomationOverlay(track, totalDurationForWidth) {
  const mode = track.automationMode;
  const auto = ensureTrackAutomation(track);
  const points = auto[mode]; // 直接参照(mutableな配列。ここへのpush/splice/sortがそのままtrack.automationに反映される)
  const staticValue = mode === 'volume' ? track.volume : track.pan;
  const widthPx = totalDurationForWidth * state.pxPerSec;
  const color = mode === 'volume' ? '#d4a548' : '#4fd1c5';

  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('width', widthPx);
  svg.setAttribute('height', TRACK_LANE_HEIGHT);
  svg.classList.add('automation-overlay');

  // 全面を覆う透明の当たり判定矩形(ここをクリックすると新しいブレイクポイントを追加)
  const bgRect = document.createElementNS(svgNS, 'rect');
  bgRect.setAttribute('x', 0); bgRect.setAttribute('y', 0);
  bgRect.setAttribute('width', widthPx); bgRect.setAttribute('height', TRACK_LANE_HEIGHT);
  bgRect.setAttribute('fill', 'transparent');
  bgRect.style.cursor = 'copy';
  svg.appendChild(bgRect);

  const visiblePath = document.createElementNS(svgNS, 'path');
  visiblePath.setAttribute('stroke', color);
  visiblePath.setAttribute('stroke-width', '2');
  visiblePath.setAttribute('fill', 'none');
  visiblePath.style.pointerEvents = 'none';
  svg.appendChild(visiblePath);

  function buildPathData() {
    if (points.length === 0) {
      const y = automationValueToY(mode, staticValue);
      return `M0,${y} L${widthPx},${y}`;
    }
    let d = `M0,${automationValueToY(mode, points[0].v)} `;
    points.forEach(p => { d += `L${(p.t * state.pxPerSec).toFixed(1)},${automationValueToY(mode, p.v).toFixed(1)} `; });
    const last = points[points.length - 1];
    d += `L${widthPx},${automationValueToY(mode, last.v).toFixed(1)}`;
    return d;
  }

  function redraw() {
    visiblePath.setAttribute('d', buildPathData());
  }

  function renderPointCircles() {
    svg.querySelectorAll('.auto-point').forEach(c => c.remove());
    points.forEach((p, idx) => {
      const circle = document.createElementNS(svgNS, 'circle');
      circle.setAttribute('cx', p.t * state.pxPerSec);
      circle.setAttribute('cy', automationValueToY(mode, p.v));
      circle.setAttribute('r', 5);
      circle.setAttribute('fill', color);
      circle.setAttribute('stroke', '#000');
      circle.setAttribute('stroke-width', '1');
      circle.classList.add('auto-point');
      circle.style.cursor = 'grab';

      circle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const svgRect = svg.getBoundingClientRect();
        const onMove = (ev) => {
          const x = ev.clientX - svgRect.left;
          const y = ev.clientY - svgRect.top;
          let newT = Math.max(0, x / state.pxPerSec);
          if (state.snap) newT = snapVal(newT);
          points[idx] = { t: newT, v: automationYToValue(mode, y) };
          points.sort((a, b) => a.t - b.t);
          redraw();
          renderPointCircles();
        };
        const onUp = () => {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
      });

      circle.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        points.splice(idx, 1);
        redraw();
        renderPointCircles();
      });

      svg.appendChild(circle);
    });
  }

  bgRect.addEventListener('click', (e) => {
    const svgRect = svg.getBoundingClientRect();
    const x = e.clientX - svgRect.left;
    const y = e.clientY - svgRect.top;
    let t = Math.max(0, x / state.pxPerSec);
    if (state.snap) t = snapVal(t);
    points.push({ t, v: automationYToValue(mode, y) });
    points.sort((a, b) => a.t - b.t);
    redraw();
    renderPointCircles();
  });

  redraw();
  renderPointCircles();
  return svg;
}

function renderTracksContainer() {
  const container = document.getElementById('tracksContainer');
  container.querySelectorAll('.track-lane').forEach(el => el.remove());
  const total = Math.max(getTotalDuration() + 20, 60);
  container.style.width = (total * state.pxPerSec) + 'px';

  const playhead = document.getElementById('playhead');

  state.tracks.forEach(track => {
    const lane = document.createElement('div');
    lane.className = 'track-lane' + (track.automationMode ? ' automation-active' : '');
    lane.dataset.track = track.id;
    lane.style.width = (total * state.pxPerSec) + 'px';

    track.clips.forEach(clip => {
      lane.appendChild(renderClipEl(track, clip));
    });

    if (track.automationMode) {
      lane.appendChild(renderAutomationOverlay(track, total));
    }

    container.appendChild(lane);
  });

  container.appendChild(playhead);
}

function escapeHtml(s) {
  return (s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function setStatus(text) {
  document.getElementById('statusText').textContent = text;
}

/* ============ クリップ描画 & 波形 ============ */

function renderClipEl(track, clip) {
  const el = document.createElement('div');
  el.className = 'clip' + (state.selectedClipIds.has(clip.id) ? ' selected' : '');
  el.dataset.clip = clip.id;
  el.dataset.track = track.id;
  positionClipEl(el, clip);
  el.style.background = shadeColor(track.color, -55);

  const label = document.createElement('div');
  label.className = 'clip-label';
  label.textContent = clipLabelText(clip);
  el.appendChild(label);

  const canvas = document.createElement('canvas');
  el.appendChild(canvas);

  const fadeInOverlay = document.createElement('div');
  fadeInOverlay.className = 'fade-overlay-in';
  el.appendChild(fadeInOverlay);
  const fadeOutOverlay = document.createElement('div');
  fadeOutOverlay.className = 'fade-overlay-out';
  el.appendChild(fadeOutOverlay);

  const leftHandle = document.createElement('div');
  leftHandle.className = 'clip-trim-handle left';
  el.appendChild(leftHandle);
  const rightHandle = document.createElement('div');
  rightHandle.className = 'clip-trim-handle right';
  el.appendChild(rightHandle);

  // 「まだ奥にカットされた部分がある」ことを示すインジケーター(«/»)。
  // トリムして見えなくなった部分を、端をドラッグすれば引っ張り出せることに気づけるようにするため。
  const leftMore = document.createElement('div');
  leftMore.className = 'clip-more-indicator left';
  leftMore.textContent = '«';
  leftMore.title = 'この手前にまだ音源が続いています。左端をドラッグすると戻せます。';
  el.appendChild(leftMore);
  const rightMore = document.createElement('div');
  rightMore.className = 'clip-more-indicator right';
  rightMore.textContent = '»';
  rightMore.title = 'この先にまだ音源が続いています。右端をドラッグすると戻せます。';
  el.appendChild(rightMore);

  function updateMoreIndicators() {
    leftMore.style.display = clip.offset > 0.05 ? 'flex' : 'none';
    const remaining = clip.sourceDuration - clip.offset - clip.duration;
    rightMore.style.display = remaining > 0.05 ? 'flex' : 'none';
  }
  updateMoreIndicators();

  const fadeInHandle = document.createElement('div');
  fadeInHandle.className = 'fade-handle in';
  el.appendChild(fadeInHandle);
  const fadeOutHandle = document.createElement('div');
  fadeOutHandle.className = 'fade-handle out';
  el.appendChild(fadeOutHandle);

  requestAnimationFrame(() => drawWaveformOnCanvas(canvas, clip));
  updateFadeVisuals(el, clip);

  attachClipInteractions(el, track, clip, { canvas, leftHandle, rightHandle, fadeInHandle, fadeOutHandle, updateMoreIndicators });

  return el;
}

function positionClipEl(el, clip) {
  el.style.left = (clip.start * state.pxPerSec) + 'px';
  el.style.width = Math.max(6, clip.duration * state.pxPerSec) + 'px';
}

function updateFadeVisuals(el, clip) {
  const widthPx = clip.duration * state.pxPerSec;
  const inPx = Math.min(widthPx * 0.6, clip.fadeIn * state.pxPerSec);
  const outPx = Math.min(widthPx * 0.6, clip.fadeOut * state.pxPerSec);
  const fadeInOverlay = el.querySelector('.fade-overlay-in');
  const fadeOutOverlay = el.querySelector('.fade-overlay-out');
  const fadeInHandle = el.querySelector('.fade-handle.in');
  const fadeOutHandle = el.querySelector('.fade-handle.out');
  fadeInOverlay.style.width = inPx + 'px';
  fadeOutOverlay.style.width = outPx + 'px';
  fadeInHandle.style.left = Math.max(0, inPx - 5) + 'px';
  fadeOutHandle.style.left = Math.max(0, widthPx - outPx - 5) + 'px';
}

function clipLabelText(clip) {
  if (clip.narrationText) {
    // ナレーションクリップはBPM表示より「編集可能」であることが分かる方が重要
    return `🎙 ${clip.narrationText.slice(0, 20)}${clip.narrationText.length > 20 ? '…' : ''} (右クリックで編集)`;
  }
  let bpmText = '';
  if (clip.detectedBpm) {
    const isStretched = clip.targetBpm && Math.round(clip.targetBpm) !== Math.round(clip.detectedBpm);
    bpmText = isStretched
      ? ` ♩${clip.detectedBpm}→${clip.targetBpm}`
      : ` ♩${clip.detectedBpm}`;
  } else {
    bpmText = ' ♩不明';
  }
  const vocalText = clip.vocalMode === 'remove' ? ' 🎤✂' : clip.vocalMode === 'isolate' ? ' 🎤only' : '';
  return clip.fileName + bpmText + vocalText;
}

function shadeColor(hex, percent) {
  const num = parseInt(hex.replace('#', ''), 16);
  let r = (num >> 16) + Math.round(2.55 * percent);
  let g = ((num >> 8) & 0x00ff) + Math.round(2.55 * percent);
  let b = (num & 0x0000ff) + Math.round(2.55 * percent);
  r = Math.max(0, Math.min(255, r));
  g = Math.max(0, Math.min(255, g));
  b = Math.max(0, Math.min(255, b));
  return `rgb(${r},${g},${b})`;
}

function drawWaveformOnCanvas(canvas, clip) {
  const buffer = getClipBuffer(clip);
  if (!buffer) return;
  const rect = canvas.getBoundingClientRect();
  const w = Math.max(1, Math.floor(rect.width));
  const h = Math.max(1, Math.floor(rect.height));
  const dpr = window.devicePixelRatio || 1;
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, w, h);

  const sr = buffer.sampleRate;
  const startSample = Math.floor(clip.offset * sr);
  const endSample = Math.min(buffer.length, Math.floor((clip.offset + clip.duration) * sr));
  const totalSamples = Math.max(1, endSample - startSample);

  const channels = [];
  for (let c = 0; c < buffer.numberOfChannels; c++) channels.push(buffer.getChannelData(c));

  ctx.fillStyle = 'rgba(79,209,197,0.85)';
  const mid = h / 2;
  const samplesPerPx = totalSamples / w;

  for (let x = 0; x < w; x++) {
    const sFrom = startSample + Math.floor(x * samplesPerPx);
    const sTo = Math.min(endSample, startSample + Math.floor((x + 1) * samplesPerPx));
    let min = 1, max = -1;
    for (let c = 0; c < channels.length; c++) {
      const data = channels[c];
      for (let i = sFrom; i < sTo; i += Math.max(1, Math.floor((sTo - sFrom) / 40) || 1)) {
        const v = data[i] || 0;
        if (v < min) min = v;
        if (v > max) max = v;
      }
    }
    if (min > max) { min = 0; max = 0; }
    const y1 = mid - max * mid * 0.9;
    const y2 = mid - min * mid * 0.9;
    ctx.fillRect(x, y1, 1, Math.max(1, y2 - y1));
  }
}

/* ============ クリップ操作(ドラッグ / トリム / フェード) ============ */

function snapVal(sec) {
  if (!state.snap) return Math.max(0, sec);
  return Math.max(0, Math.round(sec / SNAP_SEC) * SNAP_SEC);
}

function attachClipInteractions(el, track, clip, handles) {
  const { canvas, leftHandle, rightHandle, fadeInHandle, fadeOutHandle, updateMoreIndicators } = handles;

  el.addEventListener('click', (e) => {
    e.stopPropagation();
    selectClip(clip.id, (e.metaKey || e.ctrlKey) ? 'toggle' : undefined);
  });

  el.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!state.selectedClipIds.has(clip.id)) selectClip(clip.id);
    const containerRect = document.getElementById('tracksContainer').getBoundingClientRect();
    const clickTime = (e.clientX - containerRect.left) / state.pxPerSec;
    showClipContextMenu(e.clientX, e.clientY, track, clip, clickTime);
  });

  // ---- クリップ本体のドラッグ(移動)。複数選択中はまとめて移動する ----
  el.addEventListener('mousedown', (e) => {
    if (e.target === leftHandle || e.target === rightHandle ||
        e.target === fadeInHandle || e.target === fadeOutHandle) return;
    e.preventDefault();
    const startX = e.clientX;
    const isGroup = state.selectedClipIds.has(clip.id) && state.selectedClipIds.size > 1;
    const groupEntries = isGroup ? getSelectedClipEntries() : [{ track, clip }];
    const originalStarts = groupEntries.map(en => en.clip.start);
    const groupEls = groupEntries.map(en => en.clip.id === clip.id ? el : document.querySelector(`.clip[data-clip="${en.clip.id}"]`));
    const preDragSnapshot = snapshotTracks();
    el.classList.add('dragging');
    let moved = false;

    const onMove = (ev) => {
      moved = true;
      const dx = (ev.clientX - startX) / state.pxPerSec;
      groupEntries.forEach((en, i) => {
        en.clip.start = snapVal(originalStarts[i] + dx);
        if (groupEls[i]) positionClipEl(groupEls[i], en.clip);
      });
    };
    const onUp = () => {
      el.classList.remove('dragging');
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      if (moved) {
        // クリップと一緒に、その範囲にあったオートメーションの点も同じ距離だけスライドさせる
        groupEntries.forEach((en, i) => {
          const delta = en.clip.start - originalStarts[i];
          shiftAutomationForClipMove(en.track, originalStarts[i], en.clip.duration, delta);
        });
        pushUndoWithSnapshot(preDragSnapshot);
        renderRuler(); renderTracksContainer();
      }
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });

  // ---- 左トリムハンドル(開始点トリム) ----
  leftHandle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const origStart = clip.start, origOffset = clip.offset, origDuration = clip.duration;
    const preDragSnapshot = snapshotTracks();
    let moved = false;
    const onMove = (ev) => {
      moved = true;
      const dx = (ev.clientX - startX) / state.pxPerSec;
      let newOffset = origOffset + dx;
      newOffset = Math.max(0, Math.min(origOffset + origDuration - 0.2, newOffset));
      const delta = newOffset - origOffset;
      clip.offset = newOffset;
      clip.start = snapVal(origStart + delta);
      clip.duration = origDuration - delta;
      positionClipEl(el, clip);
      updateFadeVisuals(el, clip);
      updateMoreIndicators();
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      if (moved) pushUndoWithSnapshot(preDragSnapshot);
      drawWaveformOnCanvas(canvas, clip);
      renderRuler();
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });

  // ---- 右トリムハンドル(終了点トリム) ----
  rightHandle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const origDuration = clip.duration;
    const maxDuration = clip.sourceDuration - clip.offset;
    const preDragSnapshot = snapshotTracks();
    let moved = false;
    const onMove = (ev) => {
      moved = true;
      const dx = (ev.clientX - startX) / state.pxPerSec;
      let newDuration = origDuration + dx;
      newDuration = Math.max(0.2, Math.min(maxDuration, newDuration));
      clip.duration = newDuration;
      positionClipEl(el, clip);
      updateFadeVisuals(el, clip);
      updateMoreIndicators();
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      if (moved) pushUndoWithSnapshot(preDragSnapshot);
      drawWaveformOnCanvas(canvas, clip);
      renderRuler();
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });

  // ---- フェードイン ハンドル ----
  fadeInHandle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const orig = clip.fadeIn;
    const preDragSnapshot = snapshotTracks();
    let moved = false;
    const onMove = (ev) => {
      moved = true;
      const dx = (ev.clientX - startX) / state.pxPerSec;
      clip.fadeIn = Math.max(0, Math.min(clip.duration * 0.9, orig + dx));
      updateFadeVisuals(el, clip);
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      if (moved) pushUndoWithSnapshot(preDragSnapshot);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });

  // ---- フェードアウト ハンドル ----
  fadeOutHandle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const orig = clip.fadeOut;
    const preDragSnapshot = snapshotTracks();
    let moved = false;
    const onMove = (ev) => {
      moved = true;
      const dx = (ev.clientX - startX) / state.pxPerSec;
      clip.fadeOut = Math.max(0, Math.min(clip.duration * 0.9, orig - dx));
      updateFadeVisuals(el, clip);
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      if (moved) pushUndoWithSnapshot(preDragSnapshot);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
}

// mode: undefined(単独選択・既存選択をクリア) | 'toggle'(Ctrl/Cmd+クリックで追加/除外)
function selectClip(clipId, mode) {
  if (clipId === null) {
    state.selectedClipIds.clear();
  } else if (mode === 'toggle') {
    if (state.selectedClipIds.has(clipId)) state.selectedClipIds.delete(clipId);
    else state.selectedClipIds.add(clipId);
  } else {
    state.selectedClipIds.clear();
    state.selectedClipIds.add(clipId);
  }
  document.querySelectorAll('.clip').forEach(el => {
    el.classList.toggle('selected', state.selectedClipIds.has(el.dataset.clip));
  });
}

function getSelectedClipEntries() {
  const entries = [];
  state.tracks.forEach(track => {
    track.clips.forEach(clip => {
      if (state.selectedClipIds.has(clip.id)) entries.push({ track, clip });
    });
  });
  return entries;
}

// clipが複数選択の一部なら選択中の全クリップに、そうでなければclip単体にfnを適用する
function applyToSelectionOrClip(clip, fn) {
  if (state.selectedClipIds.has(clip.id) && state.selectedClipIds.size > 1) {
    getSelectedClipEntries().forEach(({ clip: c }) => fn(c));
  } else {
    fn(clip);
  }
}

function deleteClip(track, clip, options) {
  if (!(options && options.skipUndo)) pushUndo();
  track.clips = track.clips.filter(c => c.id !== clip.id);
  renderAll();
}

function deleteSelectedClips() {
  const entries = getSelectedClipEntries();
  if (entries.length === 0) return;
  pushUndo();
  entries.forEach(({ track, clip }) => deleteClip(track, clip, { skipUndo: true }));
  state.selectedClipIds.clear();
  renderAll();
  setStatus(`${entries.length}件のクリップを削除しました。`);
}

function duplicateClip(track, clip) {
  pushUndo();
  const pastePos = snapVal(getCurrentTimelinePosition());
  const copy = { ...clip, id: uid(), start: pastePos };
  track.clips.push(copy);
  renderAll();
  selectClip(copy.id);
  setStatus(`「${clip.fileName}」を再生ヘッドの位置に複製しました。`);
}

function splitClipAt(track, clip, timelineTime, options) {
  const margin = 0.08;
  if (timelineTime <= clip.start + margin || timelineTime >= clip.start + clip.duration - margin) {
    setStatus('⚠ 分割位置がクリップの端に近すぎます。クリップの内側をクリックしてから右クリックしてください。');
    return;
  }
  if (!(options && options.skipUndo)) pushUndo();
  const cutAt = timelineTime - clip.start; // クリップ先頭からの経過秒数

  const secondHalf = {
    ...clip,
    id: uid(),
    start: clip.start + cutAt,
    offset: clip.offset + cutAt,
    duration: clip.duration - cutAt,
    fadeIn: 0,        // 分割で生まれた新しい先頭にはフェードなし
    fadeOut: clip.fadeOut, // 末尾側のフェードは引き継ぐ
  };
  clip.duration = cutAt;
  clip.fadeOut = 0;    // 分割で生まれた新しい末尾にはフェードなし(元の末尾フェードはsecondHalf側へ)

  track.clips.push(secondHalf);
  renderAll();
  setStatus(`「${clip.fileName}」を分割しました。`);
}

function showClipContextMenu(x, y, track, clip, clickTime) {
  const menu = document.getElementById('clipContextMenu');
  const bpmLine = clip.detectedBpm
    ? `検出BPM: ${clip.detectedBpm} (信頼度${Math.round((clip.bpmConfidence || 0) * 100)}%)`
    : '検出BPM: 不明';
  const vocalLine = clip.vocalMode
    ? `ボーカル処理中: ${clip.vocalMode === 'remove' ? '除去(カラオケ)' : '抽出(アカペラ)'}`
    : 'ボーカル処理: なし';
  menu.innerHTML = `
    ${clip.narrationText ? '<div class="context-menu-item" data-act="editNarration">🎙 ナレーションを編集(声/速さ/テキスト)...</div>' : ''}
    <div class="context-menu-item" data-act="split">ここで分割</div>
    <div class="context-menu-item" data-act="duplicate">複製</div>
    <div class="context-menu-item" data-act="fade05">両端フェード 0.5秒に設定</div>
    <div class="context-menu-item" data-act="fade10">両端フェード 1.0秒に設定</div>
    <div class="context-menu-item" data-act="fade0">フェード解除</div>
    <div class="context-menu-item" style="opacity:.6;cursor:default;pointer-events:none;">${bpmLine}</div>
    <div class="context-menu-item" data-act="bpmChange">BPMを変更(タイムストレッチ)...</div>
    <div class="context-menu-item" data-act="bpmFix">元BPMを手動設定...</div>
    <div class="context-menu-item" data-act="bpmReset">BPMを元に戻す</div>
    <div class="context-menu-item" style="opacity:.6;cursor:default;pointer-events:none;">${vocalLine}</div>
    <div class="context-menu-item" data-act="vocalRemove">ボーカル除去(疑似カラオケ)</div>
    <div class="context-menu-item" data-act="vocalIsolate">ボーカル抽出(疑似アカペラ)</div>
    ${clip.vocalMode ? '<div class="context-menu-item" data-act="vocalRevert">ボーカル処理を元に戻す</div>' : ''}
    <div class="context-menu-item danger" data-act="delete">クリップを削除</div>
  `;
  menu.style.left = x + 'px';
  menu.style.top = y + 'px';
  menu.classList.remove('hidden');

  menu.querySelectorAll('.context-menu-item[data-act]').forEach(item => {
    item.onclick = async () => {
      const act = item.dataset.act;
      menu.classList.add('hidden');
      if (act === 'delete') deleteClip(track, clip);
      if (act === 'duplicate') duplicateClip(track, clip);
      if (act === 'split') splitClipAt(track, clip, clickTime);
      if (act === 'editNarration') openNarrationPanel({ editingTrack: track, editingClip: clip });
      if (act === 'fade05') { pushUndo(); applyToSelectionOrClip(clip, c => { c.fadeIn = 0.5; c.fadeOut = 0.5; }); renderAll(); }
      if (act === 'fade10') { pushUndo(); applyToSelectionOrClip(clip, c => { c.fadeIn = 1.0; c.fadeOut = 1.0; }); renderAll(); }
      if (act === 'fade0') { pushUndo(); applyToSelectionOrClip(clip, c => { c.fadeIn = 0; c.fadeOut = 0; }); renderAll(); }
      if (act === 'vocalRemove') await applyVocalProcess(clip, 'remove');
      if (act === 'vocalIsolate') await applyVocalProcess(clip, 'isolate');
      if (act === 'vocalRevert') revertVocalProcess(clip);
      if (act === 'bpmFix') {
        const v = prompt('この音源の元BPMを手動で入力してください(自動検出が誤っている場合):', clip.detectedBpm || 120);
        const bpm = parseFloat(v);
        if (v !== null && !isNaN(bpm) && bpm > 0) {
          clip.detectedBpm = bpm;
          clip.bpmConfidence = 1;
          clip.targetBpm = bpm;
          clip.playSourceId = clip.sourceId;
          clip.sourceDuration = audioBufferCache[clip.sourceId].duration;
          clip.offset = 0;
          clip.duration = clip.sourceDuration;
          renderAll();
        }
      }
      if (act === 'bpmChange') {
        if (!clip.detectedBpm) { alert('元BPMが未確定です。先に「元BPMを手動設定」を行ってください。'); return; }
        const v = prompt(`目標BPMを入力してください(現在の検出BPM: ${clip.detectedBpm}):`, clip.targetBpm || clip.detectedBpm);
        const bpm = parseFloat(v);
        if (v !== null && !isNaN(bpm) && bpm > 0) await applyBpmStretch(clip, bpm);
      }
      if (act === 'bpmReset') {
        if (clip.detectedBpm) await applyBpmStretch(clip, clip.detectedBpm);
      }
    };
  });
}

let suppressNextDeselect = false; // マーキー選択直後の click イベントで選択が消えるのを防ぐガード

document.addEventListener('click', (e) => {
  const menu = document.getElementById('clipContextMenu');
  if (!menu.contains(e.target)) menu.classList.add('hidden');
  if (suppressNextDeselect) { suppressNextDeselect = false; return; }
  if (!e.target.closest('.clip')) selectClip(null);
});

/* ============ 再生エンジン ============ */

function ensureTrackNodes() {
  const ctx = getAudioCtx();
  state.tracks.forEach(track => {
    if (!trackGainNodes[track.id]) {
      const gain = ctx.createGain();
      const pan = ctx.createStereoPanner();
      pan.pan.value = track.pan;
      gain.connect(pan);
      const effects = buildTrackEffectsChain(ctx, pan, masterGain, normalizeEffects(track.effects));
      trackGainNodes[track.id] = { gain, pan, effects };
    }
  });
  // 不要になったノードを掃除
  Object.keys(trackGainNodes).forEach(id => {
    if (!state.tracks.find(t => t.id === id)) {
      const node = trackGainNodes[id];
      try { node.gain.disconnect(); } catch (e) {}
      try { node.pan.disconnect(); } catch (e) {}
      Object.values(node.effects || {}).forEach(n => {
        try { n.stop && n.stop(); } catch (e) {}
        try { n.disconnect(); } catch (e) {}
      });
      delete trackGainNodes[id];
    }
  });
}

function applyLiveMixState() {
  ensureTrackNodes();
  const anySolo = state.tracks.some(t => t.solo);
  state.tracks.forEach(track => {
    const node = trackGainNodes[track.id];
    if (!node) return;
    const audible = anySolo ? track.solo : !track.muted;
    node.gain.gain.value = audible ? track.volume : 0;
    node.pan.pan.value = track.pan;
  });
}

/* ============ トラックFX (ディレイ/フィルター/リバーブ) ============ */

function createImpulseResponse(ctx, durationSec, decay) {
  const rate = ctx.sampleRate;
  const length = Math.max(1, Math.floor(rate * durationSec));
  const impulse = ctx.createBuffer(2, length, rate);
  for (let ch = 0; ch < 2; ch++) {
    const data = impulse.getChannelData(ch);
    for (let i = 0; i < length; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
    }
  }
  return impulse;
}

// input -> [ディレイ] -> [フィルター] -> [リバーブ] -> output という直列チェーンを構築する。
// 各エフェクトは常時接続済みで、"enabled=false"はwetゲインを0にすることで表現する
// (グラフを繋ぎ直さないのでON/OFF切り替え時にクリックノイズが出にくい)。
// ライブ再生(persistent AudioContext)・オフライン書き出し(OfflineAudioContext)の両方で共用する。
function buildTrackEffectsChain(ctx, inputNode, outputNode, effects) {
  const bus0 = ctx.createGain();
  inputNode.connect(bus0);

  // ---- ディレイ/エコー ----
  const delayNode = ctx.createDelay(5.0);
  delayNode.delayTime.value = effects.delay.timeSec;
  const feedbackGain = ctx.createGain();
  feedbackGain.gain.value = Math.min(0.92, effects.delay.feedback);
  const delayWet = ctx.createGain();
  delayWet.gain.value = effects.delay.enabled ? effects.delay.mix : 0;
  const delayDry = ctx.createGain();
  delayDry.gain.value = 1;
  const delayBus = ctx.createGain();
  bus0.connect(delayDry); delayDry.connect(delayBus);
  bus0.connect(delayNode); delayNode.connect(feedbackGain); feedbackGain.connect(delayNode);
  delayNode.connect(delayWet); delayWet.connect(delayBus);

  // ---- フィルター (ローパス/ハイパス) ----
  const filterNode = ctx.createBiquadFilter();
  filterNode.type = effects.filter.type;
  filterNode.frequency.value = effects.filter.freq;
  filterNode.Q.value = 0.9;
  const filterWet = ctx.createGain();
  filterWet.gain.value = effects.filter.enabled ? effects.filter.mix : 0;
  const filterDry = ctx.createGain();
  filterDry.gain.value = effects.filter.enabled ? 1 - effects.filter.mix : 1;
  const filterBus = ctx.createGain();
  delayBus.connect(filterDry); filterDry.connect(filterBus);
  delayBus.connect(filterNode); filterNode.connect(filterWet); filterWet.connect(filterBus);

  // ---- リングモジュレーター (宇宙人/ロボット声。搬送波との掛け算で金属的な音色を作る) ----
  const ringOsc = ctx.createOscillator();
  ringOsc.type = 'sine';
  ringOsc.frequency.value = effects.ring.freq;
  const ringGain = ctx.createGain();
  ringGain.gain.value = 0; // 基準値0にして、オシレーターの振幅(-1〜1)がそのまま乗算係数になる
  ringOsc.connect(ringGain.gain);
  ringOsc.start();
  const ringWet = ctx.createGain();
  ringWet.gain.value = effects.ring.enabled ? effects.ring.mix : 0;
  const ringDry = ctx.createGain();
  ringDry.gain.value = 1;
  const ringBus = ctx.createGain();
  filterBus.connect(ringDry); ringDry.connect(ringBus);
  filterBus.connect(ringGain); ringGain.connect(ringWet); ringWet.connect(ringBus);

  // ---- リバーブ (合成インパルス応答によるコンボリューション) ----
  const convolver = ctx.createConvolver();
  convolver.normalize = true;
  convolver.buffer = createImpulseResponse(ctx, effects.reverb.size || 2.2, 2.3);
  const reverbWet = ctx.createGain();
  reverbWet.gain.value = effects.reverb.enabled ? effects.reverb.mix : 0;
  const reverbDry = ctx.createGain();
  reverbDry.gain.value = 1;
  ringBus.connect(reverbDry); reverbDry.connect(outputNode);
  ringBus.connect(convolver); convolver.connect(reverbWet); reverbWet.connect(outputNode);

  return {
    bus0, delayNode, feedbackGain, delayWet, delayDry, delayBus,
    filterNode, filterWet, filterDry, filterBus,
    ringOsc, ringGain, ringWet, ringDry, ringBus,
    convolver, reverbWet, reverbDry,
  };
}

function updateTrackEffectParams(track) {
  const node = trackGainNodes[track.id];
  if (!node) return;
  const nodes = node.effects;
  const ctx = getAudioCtx();
  const t = ctx.currentTime;
  const d = track.effects.delay, f = track.effects.filter, rv = track.effects.reverb, rg = track.effects.ring;
  nodes.delayNode.delayTime.setTargetAtTime(d.timeSec, t, 0.02);
  nodes.feedbackGain.gain.setTargetAtTime(Math.min(0.92, d.feedback), t, 0.02);
  nodes.delayWet.gain.setTargetAtTime(d.enabled ? d.mix : 0, t, 0.02);
  nodes.filterNode.type = f.type;
  nodes.filterNode.frequency.setTargetAtTime(f.freq, t, 0.02);
  nodes.filterWet.gain.setTargetAtTime(f.enabled ? f.mix : 0, t, 0.02);
  nodes.filterDry.gain.setTargetAtTime(f.enabled ? 1 - f.mix : 1, t, 0.02);
  nodes.ringOsc.frequency.setTargetAtTime(rg.freq, t, 0.02);
  nodes.ringWet.gain.setTargetAtTime(rg.enabled ? rg.mix : 0, t, 0.02);
  nodes.reverbWet.gain.setTargetAtTime(rv.enabled ? rv.mix : 0, t, 0.02);
}

function rebuildReverbBuffer(track) {
  const node = trackGainNodes[track.id];
  if (!node) return;
  node.effects.convolver.buffer = createImpulseResponse(getAudioCtx(), track.effects.reverb.size, 2.3);
}

function showTrackEffectsPanel(track, anchorEl) {
  ensureTrackNodes(); // このトラックのライブノードがまだ無ければ先に作る(値を即反映できるように)
  let panel = document.getElementById('fxPanel');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'fxPanel';
    panel.className = 'fx-panel hidden';
    document.body.appendChild(panel);
  }
  const rect = anchorEl.getBoundingClientRect();
  const left = Math.min(window.innerWidth - 316, rect.right + 8);
  panel.style.left = Math.max(8, left) + 'px';
  panel.style.top = Math.min(window.innerHeight - 320, rect.top) + 'px';
  panel.classList.remove('hidden');

  const e = track.effects;
  panel.innerHTML = `
    <div class="fx-panel-title">FX — ${escapeHtml(track.name)} <span class="fx-close" id="fxClose">✕</span></div>

    <div class="fx-section">
      <label><input type="checkbox" id="fxDelayOn" ${e.delay.enabled ? 'checked' : ''}/> ディレイ / エコー</label>
      <div class="fx-row"><span>タイム</span><input type="range" id="fxDelayTime" min="0.05" max="1.5" step="0.01" value="${e.delay.timeSec}"/><span id="fxDelayTimeVal">${e.delay.timeSec.toFixed(2)}s</span></div>
      <div class="fx-row"><span>フィードバック</span><input type="range" id="fxDelayFb" min="0" max="0.9" step="0.01" value="${e.delay.feedback}"/><span id="fxDelayFbVal">${Math.round(e.delay.feedback * 100)}%</span></div>
      <div class="fx-row"><span>ミックス量</span><input type="range" id="fxDelayMix" min="0" max="1" step="0.01" value="${e.delay.mix}"/><span id="fxDelayMixVal">${Math.round(e.delay.mix * 100)}%</span></div>
    </div>

    <div class="fx-section">
      <label><input type="checkbox" id="fxFilterOn" ${e.filter.enabled ? 'checked' : ''}/> フィルター</label>
      <div class="fx-row">
        <select id="fxFilterType">
          <option value="lowpass" ${e.filter.type === 'lowpass' ? 'selected' : ''}>ローパス</option>
          <option value="highpass" ${e.filter.type === 'highpass' ? 'selected' : ''}>ハイパス</option>
        </select>
        <input type="range" id="fxFilterFreq" min="100" max="16000" step="10" value="${e.filter.freq}"/>
        <span id="fxFilterFreqVal">${e.filter.freq}Hz</span>
      </div>
    </div>

    <div class="fx-section">
      <label><input type="checkbox" id="fxRingOn" ${e.ring.enabled ? 'checked' : ''}/> リングモジュレーター(宇宙人/ロボット声)</label>
      <div class="fx-row"><span>周波数</span><input type="range" id="fxRingFreq" min="20" max="800" step="1" value="${e.ring.freq}"/><span id="fxRingFreqVal">${e.ring.freq}Hz</span></div>
      <div class="fx-row"><span>ミックス量</span><input type="range" id="fxRingMix" min="0" max="1" step="0.01" value="${e.ring.mix}"/><span id="fxRingMixVal">${Math.round(e.ring.mix * 100)}%</span></div>
    </div>

    <div class="fx-section">
      <label><input type="checkbox" id="fxReverbOn" ${e.reverb.enabled ? 'checked' : ''}/> リバーブ</label>
      <div class="fx-row"><span>ミックス量</span><input type="range" id="fxReverbMix" min="0" max="1" step="0.01" value="${e.reverb.mix}"/><span id="fxReverbMixVal">${Math.round(e.reverb.mix * 100)}%</span></div>
      <div class="fx-row"><span>空間サイズ</span><input type="range" id="fxReverbSize" min="0.5" max="5" step="0.1" value="${e.reverb.size}"/><span id="fxReverbSizeVal">${e.reverb.size.toFixed(1)}s</span></div>
    </div>
  `;

  document.getElementById('fxClose').onclick = () => panel.classList.add('hidden');

  const bindRange = (id, valId, fmt, onChange) => {
    const el = document.getElementById(id);
    el.addEventListener('input', () => {
      const v = parseFloat(el.value);
      onChange(v);
      if (valId) document.getElementById(valId).textContent = fmt(v);
      updateTrackEffectParams(track);
      renderTrackHeaders();
    });
  };

  document.getElementById('fxDelayOn').addEventListener('change', ev => { e.delay.enabled = ev.target.checked; updateTrackEffectParams(track); renderTrackHeaders(); });
  bindRange('fxDelayTime', 'fxDelayTimeVal', v => v.toFixed(2) + 's', v => { e.delay.timeSec = v; });
  bindRange('fxDelayFb', 'fxDelayFbVal', v => Math.round(v * 100) + '%', v => { e.delay.feedback = v; });
  bindRange('fxDelayMix', 'fxDelayMixVal', v => Math.round(v * 100) + '%', v => { e.delay.mix = v; });

  document.getElementById('fxRingOn').addEventListener('change', ev => { e.ring.enabled = ev.target.checked; updateTrackEffectParams(track); renderTrackHeaders(); });
  bindRange('fxRingFreq', 'fxRingFreqVal', v => Math.round(v) + 'Hz', v => { e.ring.freq = v; });
  bindRange('fxRingMix', 'fxRingMixVal', v => Math.round(v * 100) + '%', v => { e.ring.mix = v; });

  document.getElementById('fxFilterOn').addEventListener('change', ev => { e.filter.enabled = ev.target.checked; updateTrackEffectParams(track); renderTrackHeaders(); });
  document.getElementById('fxFilterType').addEventListener('change', ev => { e.filter.type = ev.target.value; updateTrackEffectParams(track); });
  bindRange('fxFilterFreq', 'fxFilterFreqVal', v => Math.round(v) + 'Hz', v => { e.filter.freq = v; });

  document.getElementById('fxReverbOn').addEventListener('change', ev => { e.reverb.enabled = ev.target.checked; updateTrackEffectParams(track); renderTrackHeaders(); });
  bindRange('fxReverbMix', 'fxReverbMixVal', v => Math.round(v * 100) + '%', v => { e.reverb.mix = v; });
  bindRange('fxReverbSize', 'fxReverbSizeVal', v => v.toFixed(1) + 's', v => { e.reverb.size = v; rebuildReverbBuffer(track); });
}

document.addEventListener('click', (e) => {
  const panel = document.getElementById('fxPanel');
  if (panel && !panel.classList.contains('hidden') && !panel.contains(e.target) && !e.target.classList.contains('track-fx-btn')) {
    panel.classList.add('hidden');
  }
});

/* ============ ナレーション (テキスト→音声、macOS sayコマンド) ============ */

async function generateNarration(text, voice, rate) {
  if (!text || !text.trim()) { setStatus('テキストを入力してください。'); return null; }
  setStatus('ナレーションを生成中(sayコマンド)...');
  const result = await window.electronAPI.synthesizeNarration({ text: text.trim(), voice, rate });
  if (!result || !result.ok) {
    setStatus('⚠ ナレーション生成に失敗しました: ' + (result && result.error ? result.error : '不明なエラー'));
    return null;
  }
  const arrayBuffer = base64ToArrayBuffer(result.base64);
  const shortLabel = text.trim().replace(/\s+/g, ' ').slice(0, 14) || 'ナレーション';
  const fileName = `nrt_${shortLabel}.wav`;
  const appendAt = getMaxTrackEnd();
  await addAudioFileToTimeline(fileName, result.filePath, arrayBuffer, appendAt);
  const newTrack = state.tracks[state.tracks.length - 1];
  // 後から「声・速さ・テキスト」を編集できるよう、生成時のパラメータをクリップに記録しておく
  const clip = newTrack.clips[0];
  if (clip) {
    clip.narrationText = text.trim();
    clip.narrationVoice = voice || '';
    clip.narrationRate = rate;
  }
  return newTrack;
}

// 既存のナレーションクリップを新しいテキスト/声/速さで再生成し、同じ位置に差し替える
async function updateNarrationClip(track, clip, text, voice, rate) {
  if (!text || !text.trim()) { setStatus('テキストを入力してください。'); return false; }
  setStatus('ナレーションを更新中(sayコマンド)...');
  const result = await window.electronAPI.synthesizeNarration({ text: text.trim(), voice, rate });
  if (!result || !result.ok) {
    setStatus('⚠ ナレーション更新に失敗しました: ' + (result && result.error ? result.error : '不明なエラー'));
    return false;
  }
  const arrayBuffer = base64ToArrayBuffer(result.base64);
  const buffer = await getAudioCtx().decodeAudioData(arrayBuffer.slice(0));

  // 古い音声データのキャッシュ(この差し替え専用の一時ファイル)は使い回さないので破棄してよい
  audioBufferCache[result.filePath] = buffer;

  const shortLabel = text.trim().replace(/\s+/g, ' ').slice(0, 14) || 'ナレーション';
  pushUndo();
  clip.sourceId = result.filePath;
  clip.playSourceId = result.filePath; // BPM変更やボーカル処理のキャッシュは新音声には引き継がない(別物のため)
  clip.filePath = result.filePath;
  clip.fileName = `nrt_${shortLabel}.wav`;
  clip.sourceDuration = buffer.duration;
  clip.offset = 0;
  clip.duration = buffer.duration; // 長さが変わるのでフル尺にリセット
  clip.fadeIn = Math.min(clip.fadeIn || 0, buffer.duration / 2);
  clip.fadeOut = Math.min(clip.fadeOut || 0, buffer.duration / 2);
  clip.detectedBpm = null; clip.targetBpm = null; clip.bpmConfidence = 0; // 音声が別物になるため無効化
  clip.vocalMode = null; clip.preVocalSourceId = null;
  clip.narrationText = text.trim();
  clip.narrationVoice = voice || '';
  clip.narrationRate = rate;

  renderAll();
  setStatus(`ナレーションを更新しました:「${text.trim().slice(0, 24)}${text.trim().length > 24 ? '…' : ''}」`);
  return true;
}

// 宇宙人/モザイクは専用DSPを新設せず、既存のリングモジュレーター+フィルターの組み合わせで作る
function applyVoicePreset(track, preset) {
  if (!track) return;
  const e = track.effects;
  if (preset === 'alien') {
    e.ring.enabled = true; e.ring.freq = 120; e.ring.mix = 0.6;
    e.filter.enabled = false;
  } else if (preset === 'mosaic') {
    e.ring.enabled = true; e.ring.freq = 55; e.ring.mix = 0.3;
    e.filter.enabled = true; e.filter.type = 'lowpass'; e.filter.freq = 2200; e.filter.mix = 0.8;
  } else {
    e.ring.enabled = false;
    e.filter.enabled = false;
  }
  ensureTrackNodes();
  updateTrackEffectParams(track);
  renderAll();
}

function openNarrationPanel(editing) {
  const isEdit = !!(editing && editing.editingClip);
  let panel = document.getElementById('narrationPanel');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'narrationPanel';
    panel.className = 'fx-panel narration-panel hidden';
    document.body.appendChild(panel);
  }
  panel.classList.remove('hidden');
  const prefillText = isEdit ? editing.editingClip.narrationText || '' : '';
  const prefillRate = isEdit ? (editing.editingClip.narrationRate || 190) : 190;
  panel.innerHTML = `
    <div class="fx-panel-title">🎙 ${isEdit ? 'ナレーションを編集' : 'ナレーション追加'} <span class="fx-close" id="narrationClose">✕</span></div>
    <textarea id="narrationText" rows="4" placeholder="読み上げるテキストを入力...">${escapeHtml(prefillText)}</textarea>
    <div class="fx-row"><span>声</span><select id="narrationVoice"><option>読込中...</option></select></div>
    <div class="fx-row"><span>速さ</span><input type="range" id="narrationRate" min="120" max="260" step="5" value="${prefillRate}"/><span id="narrationRateVal">${prefillRate}wpm</span></div>
    ${isEdit ? '' : `
    <div class="narration-presets">
      <button type="button" class="btn btn-small-wide preset-active" data-preset="normal">通常</button>
      <button type="button" class="btn btn-small-wide" data-preset="alien">宇宙人</button>
      <button type="button" class="btn btn-small-wide" data-preset="mosaic">モザイク</button>
    </div>`}
    <button id="narrationGenerate" class="btn btn-primary narration-generate-btn">${isEdit ? '更新する(同じ位置に差し替え)' : 'タイムラインに追加'}</button>
    <div id="narrationStatus" class="narration-status"></div>
  `;
  panel.style.left = '50%';
  panel.style.top = '78px';
  panel.style.transform = 'translateX(-50%)';

  document.getElementById('narrationClose').onclick = () => panel.classList.add('hidden');

  let selectedPreset = 'normal';
  panel.querySelectorAll('[data-preset]').forEach(btn => {
    btn.addEventListener('click', () => {
      selectedPreset = btn.dataset.preset;
      panel.querySelectorAll('[data-preset]').forEach(b => b.classList.remove('preset-active'));
      btn.classList.add('preset-active');
    });
  });

  const rateInput = document.getElementById('narrationRate');
  rateInput.addEventListener('input', () => {
    document.getElementById('narrationRateVal').textContent = rateInput.value + 'wpm';
  });

  window.electronAPI.listNarrationVoices().then(result => {
    const select = document.getElementById('narrationVoice');
    const voices = result && result.ok ? result.voices : [];
    if (!voices || voices.length === 0) {
      select.innerHTML = `<option value="">(デフォルトの声)</option>`;
      return;
    }
    voices.sort((a, b) => {
      const aJa = a.locale.startsWith('ja') ? 0 : 1;
      const bJa = b.locale.startsWith('ja') ? 0 : 1;
      return aJa - bJa;
    });
    select.innerHTML = voices.map(v => `<option value="${escapeHtml(v.name)}">${escapeHtml(v.name)} (${escapeHtml(v.locale)})</option>`).join('');
    if (isEdit && editing.editingClip.narrationVoice) select.value = editing.editingClip.narrationVoice;
  });

  document.getElementById('narrationGenerate').addEventListener('click', async () => {
    const text = document.getElementById('narrationText').value;
    const voice = document.getElementById('narrationVoice').value;
    const rate = parseInt(document.getElementById('narrationRate').value, 10);
    const statusEl = document.getElementById('narrationStatus');
    if (!text.trim()) { statusEl.textContent = 'テキストを入力してください。'; return; }
    statusEl.textContent = isEdit ? '更新中...' : '生成中...';

    if (isEdit) {
      const ok = await updateNarrationClip(editing.editingTrack, editing.editingClip, text, voice, rate);
      statusEl.textContent = ok ? '更新しました。' : '更新に失敗しました。';
      return;
    }

    const track = await generateNarration(text, voice, rate);
    if (track) {
      applyVoicePreset(track, selectedPreset);
      statusEl.textContent = `追加しました:「${text.trim().slice(0, 24)}${text.trim().length > 24 ? '…' : ''}」`;
      setStatus(`ナレーションをタイムラインに追加しました(${track.name})。`);
    } else {
      statusEl.textContent = '生成に失敗しました。';
    }
  });
}

document.addEventListener('click', (e) => {
  const panel = document.getElementById('narrationPanel');
  if (panel && !panel.classList.contains('hidden') && !panel.contains(e.target) && e.target.id !== 'btnNarration') {
    panel.classList.add('hidden');
  }
});

// クリップのフェード込みゲイン値を timeline 時間 t で取得
function clipGainAt(clip, t) {
  const t0 = clip.start, t1 = clip.start + clip.fadeIn;
  const t3 = clip.start + clip.duration, t2 = t3 - clip.fadeOut;
  if (t <= t0) return clip.fadeIn > 0 ? 0 : 1;
  if (clip.fadeIn > 0 && t < t1) return (t - t0) / (t1 - t0);
  if (t < t2) return 1;
  if (clip.fadeOut > 0 && t < t3) return Math.max(0, 1 - (t - t2) / (t3 - t2));
  return clip.fadeOut > 0 ? 0 : 1;
}

function scheduleClipEnvelope(gainNode, clip, whenCtx, fromTimelineTime) {
  const t0 = clip.start, t1 = clip.start + clip.fadeIn;
  const t3 = clip.start + clip.duration, t2 = t3 - clip.fadeOut;
  const points = [];
  if (clip.fadeIn > 0) { points.push([t0, 0]); points.push([t1, 1]); } else { points.push([t0, 1]); }
  if (clip.fadeOut > 0) { points.push([t2, 1]); points.push([t3, 0]); }
  else if (points[points.length - 1][0] !== t2) { points.push([t2, 1]); }

  const startVal = clipGainAt(clip, Math.max(fromTimelineTime, t0));
  gainNode.gain.cancelScheduledValues(whenCtx);
  gainNode.gain.setValueAtTime(Math.max(0.0001, startVal), whenCtx);
  points.filter(p => p[0] > fromTimelineTime).forEach(([time, val]) => {
    const delay = Math.max(0, time - fromTimelineTime);
    gainNode.gain.linearRampToValueAtTime(Math.max(0.0001, val), whenCtx + delay);
  });
}

function stopActiveSources() {
  state.activeSources.forEach(src => {
    try { src.stop(); } catch (e) {}
    try { src.disconnect(); } catch (e) {}
  });
  state.activeSources = [];
}

function schedulePlaybackFrom(fromTime) {
  const ctx = getAudioCtx();
  ensureTrackNodes();
  applyLiveMixState();
  stopActiveSources();

  const anySolo = state.tracks.some(t => t.solo);
  const startCtxTime = ctx.currentTime + 0.06;

  state.tracks.forEach(track => {
    const audible = anySolo ? track.solo : !track.muted;
    if (!audible) return;
    const trackNode = trackGainNodes[track.id];
    const auto = normalizeAutomation(track.automation);

    // トラック全体の音量/パンオートメーションを一度だけスケジュール
    scheduleAutomationParam(trackNode.gain.gain, auto.volume, track.volume, startCtxTime, fromTime);
    scheduleAutomationParam(trackNode.pan.pan, auto.pan, track.pan, startCtxTime, fromTime);

    track.clips.forEach(clip => {
      const buffer = getClipBuffer(clip);
      if (!buffer) return;
      const clipEnd = clip.start + clip.duration;
      if (clipEnd <= fromTime) return;

      let startDelay, bufferOffset, playDuration;
      if (clip.start >= fromTime) {
        startDelay = clip.start - fromTime;
        bufferOffset = clip.offset;
        playDuration = clip.duration;
      } else {
        startDelay = 0;
        const skipped = fromTime - clip.start;
        bufferOffset = clip.offset + skipped;
        playDuration = clip.duration - skipped;
      }
      if (playDuration <= 0.01) return;

      const src = ctx.createBufferSource();
      src.buffer = buffer;
      const clipGain = ctx.createGain();
      src.connect(clipGain).connect(trackNode.gain);

      const when = startCtxTime + startDelay;
      scheduleClipEnvelope(clipGain, clip, when, Math.max(fromTime, clip.start));
      try {
        src.start(when, Math.max(0, bufferOffset), Math.max(0.01, playDuration));
      } catch (e) { console.warn('start failed', e); }
      state.activeSources.push(src);
    });
  });

  state.isPlaying = true;
  state.playStartCtxTime = startCtxTime;
  state.playStartOffset = fromTime;
  document.getElementById('btnPlay').textContent = '❚❚';
  requestAnimationFrame(playbackTick);
}

function pausePlayback() {
  if (!state.isPlaying) return;
  const currentPos = getCurrentTimelinePosition();
  stopActiveSources();
  state.isPlaying = false;
  state.playStartOffset = currentPos;
  document.getElementById('btnPlay').textContent = '▶';
}

function stopPlayback() {
  stopActiveSources();
  state.isPlaying = false;
  state.playStartOffset = 0;
  document.getElementById('btnPlay').textContent = '▶';
  updatePlayheadPosition(0);
  updateTimeDisplay();
}

function seekTo(t) {
  const wasPlaying = state.isPlaying;
  stopActiveSources();
  state.playStartOffset = Math.max(0, t);
  updatePlayheadPosition(state.playStartOffset);
  updateTimeDisplay();
  if (wasPlaying) schedulePlaybackFrom(state.playStartOffset);
}

function getCurrentTimelinePosition() {
  if (!state.isPlaying) return state.playStartOffset;
  const ctx = getAudioCtx();
  return state.playStartOffset + (ctx.currentTime - state.playStartCtxTime);
}

function updatePlayheadPosition(t) {
  const playhead = document.getElementById('playhead');
  playhead.style.left = (t * state.pxPerSec) + 'px';
}

function updateTimeDisplay() {
  const cur = getCurrentTimelinePosition();
  const total = getTotalDuration();
  document.getElementById('timeDisplay').textContent = `${fmtTime(cur)} / ${fmtTime(total)}`;
}

function playbackTick() {
  if (!state.isPlaying) return;
  const pos = getCurrentTimelinePosition();
  const total = getTotalDuration();
  updatePlayheadPosition(pos);
  updateTimeDisplay();
  if (pos >= total) {
    stopPlayback();
    return;
  }
  requestAnimationFrame(playbackTick);
}

function togglePlay() {
  if (state.isPlaying) {
    pausePlayback();
  } else {
    getAudioCtx().resume();
    schedulePlaybackFrom(state.playStartOffset || 0);
  }
}

/* ============ ミックスダウン書き出し (WAV) ============ */

// [windowStart, windowEnd) の区間だけをオフラインレンダリングして AudioBuffer を返す
// windowStart=0, windowEnd=総尺 でフルミックスになる。部分区間を指定すればトラック分割書き出しに使える。
async function renderMixWindow(windowStart, windowEnd) {
  const sampleRate = 44100;
  const duration = Math.max(0.05, windowEnd - windowStart);

  // ディレイ/リバーブの余韻が途中で切れないよう、有効なエフェクトの残響時間分だけ余分にバッファを確保する
  let tailPad = 0.5;
  state.tracks.forEach(t => {
    const e = t.effects || createDefaultEffects();
    if (e.reverb.enabled) tailPad = Math.max(tailPad, e.reverb.size + 1.0);
    if (e.delay.enabled) tailPad = Math.max(tailPad, e.delay.timeSec * 8);
  });

  const offlineCtx = new OfflineAudioContext(2, Math.ceil((duration + tailPad) * sampleRate), sampleRate);
  const offlineMaster = offlineCtx.createGain();
  offlineMaster.gain.value = 1.0;
  offlineMaster.connect(offlineCtx.destination);

  const anySolo = state.tracks.some(t => t.solo);

  state.tracks.forEach(track => {
    const audible = anySolo ? track.solo : !track.muted;
    if (!audible) return;
    const trackGain = offlineCtx.createGain();
    const trackPan = offlineCtx.createStereoPanner();
    trackGain.connect(trackPan);
    buildTrackEffectsChain(offlineCtx, trackPan, offlineMaster, normalizeEffects(track.effects));

    const auto = normalizeAutomation(track.automation);
    scheduleAutomationParam(trackGain.gain, auto.volume, track.volume, 0, windowStart);
    scheduleAutomationParam(trackPan.pan, auto.pan, track.pan, 0, windowStart);

    track.clips.forEach(clip => {
      const srcBuffer = getClipBuffer(clip);
      if (!srcBuffer) return;
      const clipEnd = clip.start + clip.duration;
      if (clipEnd <= windowStart) return;   // 区間より前に完全に終わっている
      if (clip.start >= windowEnd) return;  // 区間より後に完全に始まる

      let startDelay, bufferOffset, playDuration, envelopeFromTime;
      if (clip.start >= windowStart) {
        startDelay = clip.start - windowStart;
        bufferOffset = clip.offset;
        playDuration = clip.duration;
        envelopeFromTime = clip.start;
      } else {
        startDelay = 0;
        const skipped = windowStart - clip.start;
        bufferOffset = clip.offset + skipped;
        playDuration = clip.duration - skipped;
        envelopeFromTime = windowStart;
      }
      if (playDuration <= 0.01) return;

      const src = offlineCtx.createBufferSource();
      src.buffer = srcBuffer;
      const clipGain = offlineCtx.createGain();
      src.connect(clipGain).connect(trackGain);
      scheduleClipEnvelope(clipGain, clip, startDelay, envelopeFromTime);
      try {
        src.start(startDelay, Math.max(0, bufferOffset), Math.max(0.01, playDuration));
      } catch (e) { console.warn(e); }
    });
  });

  return offlineCtx.startRendering();
}

async function handleExport() {
  const total = getTotalDuration();
  if (total <= 0) { setStatus('書き出す音源がありません。'); return; }

  setStatus('ミックスダウン中...');
  try {
    const rendered = await renderMixWindow(0, total);
    const wavArrayBuffer = audioBufferToWav(rendered);
    const defaultName = 'bgm_mix_' + new Date().toISOString().slice(0, 10) + '.wav';
    const result = await window.electronAPI.exportWav({ defaultName, arrayBuffer: wavArrayBuffer });
    if (result && result.ok) {
      setStatus(`書き出し完了: ${result.filePath}`);
    } else {
      setStatus('書き出しをキャンセルしました。');
    }
  } catch (err) {
    console.error(err);
    setStatus('⚠ 書き出しに失敗しました: ' + err.message);
  }
}

/* ============ トラック分割書き出し (個別WAV + CUEシート) ============ */

function computeTrackSegments() {
  const clips = [];
  state.tracks.forEach(t => t.clips.forEach(c => clips.push(c)));
  if (clips.length === 0) return [];

  const total = getTotalDuration();
  const starts = Array.from(new Set(clips.map(c => Math.round(c.start * 100) / 100))).sort((a, b) => a - b);

  const segments = [];
  for (let i = 0; i < starts.length; i++) {
    const segStart = starts[i];
    const segEnd = i + 1 < starts.length ? starts[i + 1] : total;
    if (segEnd - segStart < 0.05) continue; // ほぼ同時開始のクリップはまとめる

    let startingClip = clips.find(c => Math.abs(c.start - segStart) < 0.05);
    if (!startingClip) {
      startingClip = clips.reduce((a, b) => (Math.abs(a.start - segStart) < Math.abs(b.start - segStart) ? a : b));
    }
    segments.push({
      index: segments.length + 1,
      start: segStart,
      end: segEnd,
      label: startingClip ? startingClip.fileName.replace(/\.[^/.]+$/, '') : `Track${segments.length + 1}`,
    });
  }
  return segments;
}

function formatCueTime(sec) {
  // CUEシートは 分:秒:フレーム(1秒=75フレーム, CD-DA規格)
  const totalFrames = Math.round(sec * 75);
  const mm = Math.floor(totalFrames / (75 * 60));
  const ss = Math.floor((totalFrames % (75 * 60)) / 75);
  const ff = totalFrames % 75;
  return `${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}:${String(ff).padStart(2, '0')}`;
}

function generateCueSheet(fullMixFileName, segments) {
  const lines = [`FILE "${fullMixFileName}" WAVE`];
  segments.forEach(seg => {
    lines.push(`  TRACK ${String(seg.index).padStart(2, '0')} AUDIO`);
    lines.push(`    TITLE "${seg.label.replace(/"/g, '')}"`);
    lines.push(`    INDEX 01 ${formatCueTime(seg.start)}`);
  });
  return lines.join('\n');
}

async function handleExportTrackSplit() {
  const total = getTotalDuration();
  if (total <= 0) { setStatus('書き出す音源がありません。'); return; }

  const segments = computeTrackSegments();
  if (segments.length === 0) { setStatus('トラック分割できるクリップがありません。'); return; }

  try {
    setStatus('フルミックスを生成中...');
    const fullBuffer = await renderMixWindow(0, total);
    const fullMixFileName = 'full_mix.wav';
    const files = [{ name: fullMixFileName, kind: 'wav', arrayBuffer: audioBufferToWav(fullBuffer) }];

    for (const seg of segments) {
      setStatus(`トラック${String(seg.index).padStart(2, '0')}(${seg.label})を書き出し中... [${seg.index}/${segments.length}]`);
      const buf = await renderMixWindow(seg.start, seg.end);
      const safeLabel = seg.label.replace(/[\\/:*?"<>|]/g, '_').slice(0, 60);
      files.push({
        name: `${String(seg.index).padStart(2, '0')}_${safeLabel}.wav`,
        kind: 'wav',
        arrayBuffer: audioBufferToWav(buf),
      });
    }

    const cueText = generateCueSheet(fullMixFileName, segments);
    files.push({ name: 'mix.cue', kind: 'text', text: cueText });

    setStatus('保存先フォルダを選択してください...');
    const result = await window.electronAPI.exportTrackSplit({ defaultFolderName: 'BGM_MIX_EXPORT', files });
    if (result && result.ok) {
      setStatus(`トラック分け書き出し完了: ${result.folderPath} (フルミックス1本 + ${segments.length}トラック + CUEシート)`);
    } else {
      setStatus('書き出しをキャンセルしました。');
    }
  } catch (err) {
    console.error(err);
    setStatus('⚠ トラック分け書き出しに失敗しました: ' + err.message);
  }
}

// AudioBuffer -> 16bit PCM WAV (ArrayBuffer)
function audioBufferToWav(buffer) {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const numFrames = buffer.length;
  const bytesPerSample = 2;
  const blockAlign = numChannels * bytesPerSample;
  const dataSize = numFrames * blockAlign;
  const bufferLength = 44 + dataSize;
  const arrayBuffer = new ArrayBuffer(bufferLength);
  const view = new DataView(arrayBuffer);

  function writeString(offset, str) {
    for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
  }

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);

  const channels = [];
  for (let c = 0; c < numChannels; c++) channels.push(buffer.getChannelData(c));

  let offset = 44;
  for (let i = 0; i < numFrames; i++) {
    for (let c = 0; c < numChannels; c++) {
      let sample = Math.max(-1, Math.min(1, channels[c][i]));
      sample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, sample, true);
      offset += 2;
    }
  }
  return arrayBuffer;
}

/* ============ プロジェクト保存 / 読込 ============ */

async function handleSaveProject() {
  const project = {
    version: 1,
    createdAt: new Date().toISOString(),
    pxPerSec: state.pxPerSec,
    tracks: state.tracks.map(t => ({
      id: t.id, name: t.name, color: t.color, volume: t.volume, pan: t.pan,
      muted: t.muted, solo: t.solo, effects: t.effects,
      automation: t.automation,
      clips: t.clips.map(c => ({
        id: c.id, sourceId: c.sourceId, filePath: c.filePath, fileName: c.fileName,
        start: c.start, offset: c.offset, duration: c.duration,
        sourceDuration: c.sourceDuration, fadeIn: c.fadeIn, fadeOut: c.fadeOut,
        detectedBpm: c.detectedBpm, bpmConfidence: c.bpmConfidence, targetBpm: c.targetBpm,
        vocalMode: c.vocalMode || null, preVocalSourceId: c.preVocalSourceId || null,
        narrationText: c.narrationText || null, narrationVoice: c.narrationVoice || null, narrationRate: c.narrationRate || null,
      })),
    })),
  };
  const json = JSON.stringify(project, null, 2);
  const result = await window.electronAPI.saveProject({ defaultName: 'project.bgmmix.json', json });
  if (result && result.ok) setStatus(`プロジェクトを保存しました: ${result.filePath}`);
}

async function handleLoadProject() {
  setStatus('プロジェクトを読込中...');
  const result = await window.electronAPI.loadProject();
  if (!result || !result.ok) { setStatus('読込をキャンセルしました。'); return; }

  const { project, missing } = result;
  stopPlayback();
  state.tracks = [];
  Object.keys(trackGainNodes).forEach(id => delete trackGainNodes[id]);

  for (const t of project.tracks) {
    const track = {
      id: t.id, name: t.name, color: t.color, volume: t.volume, pan: t.pan, muted: t.muted, solo: t.solo,
      effects: normalizeEffects(t.effects),
      automation: normalizeAutomation(t.automation),
      automationMode: null, // 読込直後は自動化レーンは非表示状態にしておく
      clips: [],
    };
    for (const c of t.clips) {
      if (c.base64 && !audioBufferCache[c.sourceId]) {
        try {
          const arrayBuffer = base64ToArrayBuffer(c.base64);
          const buffer = await getAudioCtx().decodeAudioData(arrayBuffer.slice(0));
          audioBufferCache[c.sourceId] = buffer;
        } catch (e) { console.error('decode failed on load', c.fileName, e); }
      }

      let playSourceId = c.sourceId;
      const needsStretch = c.detectedBpm && c.targetBpm && Math.round(c.detectedBpm) !== Math.round(c.targetBpm);
      if (needsStretch && audioBufferCache[c.sourceId]) {
        const stretchRatio = c.detectedBpm / c.targetBpm;
        const cacheKey = `${c.sourceId}__bpm${c.targetBpm.toFixed(2)}`;
        if (!audioBufferCache[cacheKey]) {
          setStatus(`${c.fileName} のテンポを再構築中(${c.detectedBpm}→${c.targetBpm}BPM)...`);
          audioBufferCache[cacheKey] = await timeStretchBuffer(audioBufferCache[c.sourceId], stretchRatio);
        }
        playSourceId = cacheKey;
      }

      if (c.vocalMode && audioBufferCache[playSourceId]) {
        const vocalCacheKey = `${playSourceId}__vocal_${c.vocalMode}`;
        if (!audioBufferCache[vocalCacheKey]) {
          setStatus(`${c.fileName} のボーカル処理を再構築中...`);
          try {
            audioBufferCache[vocalCacheKey] = await processCenterChannel(audioBufferCache[playSourceId], c.vocalMode);
          } catch (e) { console.error('vocal process rebuild failed', c.fileName, e); }
        }
        if (audioBufferCache[vocalCacheKey]) playSourceId = vocalCacheKey;
      }

      track.clips.push({
        id: c.id, sourceId: c.sourceId, playSourceId, filePath: c.filePath, fileName: c.fileName,
        start: c.start, offset: c.offset, duration: c.duration,
        sourceDuration: c.sourceDuration, fadeIn: c.fadeIn || 0, fadeOut: c.fadeOut || 0,
        detectedBpm: c.detectedBpm || null, bpmConfidence: c.bpmConfidence || 0, targetBpm: c.targetBpm || null,
        vocalMode: c.vocalMode || null, preVocalSourceId: c.preVocalSourceId || null,
        narrationText: c.narrationText || null, narrationVoice: c.narrationVoice || null, narrationRate: c.narrationRate || null,
      });
    }
    state.tracks.push(track);
  }
  state.pxPerSec = project.pxPerSec || 40;
  renderAll();

  if (missing && missing.length > 0) {
    setStatus(`⚠ ${missing.length}件の音声ファイルが見つかりませんでした(移動/削除された可能性): ${missing.join(', ')}`);
  } else {
    setStatus('プロジェクトを読み込みました。');
  }
}

/* ============ BPM自動検出 (ローパス→エンベロープ→ピーク検出→区間ヒストグラム) ============ */

async function detectBpmForBuffer(originalBuffer) {
  try {
    const sr = originalBuffer.sampleRate;
    // 解析は最大120秒まで(長尺曲の処理負荷軽減。BPMは曲中で通常一定なので十分)
    const analyzeSamples = Math.min(originalBuffer.length, sr * 120);

    const offlineCtx = new OfflineAudioContext(1, analyzeSamples, sr);
    const src = offlineCtx.createBufferSource();
    src.buffer = originalBuffer;
    // キック/ベース帯域を強調するローパスフィルタ(ビート検出の定番手法)
    const lowpass = offlineCtx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 150;
    lowpass.Q.value = 1;
    src.connect(lowpass).connect(offlineCtx.destination);
    src.start(0);
    const rendered = await offlineCtx.startRendering();
    const data = rendered.getChannelData(0);

    // 20msウィンドウでRMSエンベロープを作成(整流+平滑化)
    const windowSize = Math.round(sr * 0.02);
    const envelope = [];
    for (let i = 0; i < data.length; i += windowSize) {
      let sum = 0;
      const end = Math.min(data.length, i + windowSize);
      for (let j = i; j < end; j++) sum += data[j] * data[j];
      envelope.push(Math.sqrt(sum / (end - i)));
    }
    const envSr = sr / windowSize;

    const mean = envelope.reduce((a, b) => a + b, 0) / envelope.length;
    const variance = envelope.reduce((a, b) => a + (b - mean) ** 2, 0) / envelope.length;
    const std = Math.sqrt(variance);
    const threshold = mean + std * 0.5;

    // 最大220BPM相当の最小間隔を空けてピーク(拍)をピッキング
    const minIntervalFrames = Math.round(envSr * (60 / 220));
    const peaks = [];
    let lastPeak = -Infinity;
    for (let i = 1; i < envelope.length - 1; i++) {
      if (envelope[i] > threshold && envelope[i] >= envelope[i - 1] && envelope[i] >= envelope[i + 1]) {
        if (i - lastPeak >= minIntervalFrames) {
          peaks.push(i);
          lastPeak = i;
        }
      }
    }
    if (peaks.length < 4) return null;

    // 拍間隔をBPMに変換し、70-180の範囲にオクターブ折り畳みしてヒストグラム投票
    const bpmVotes = {};
    for (let i = 1; i < peaks.length; i++) {
      const intervalSec = (peaks[i] - peaks[i - 1]) / envSr;
      if (intervalSec <= 0) continue;
      let bpm = 60 / intervalSec;
      while (bpm < 70) bpm *= 2;
      while (bpm > 180) bpm /= 2;
      const rounded = Math.round(bpm);
      bpmVotes[rounded] = (bpmVotes[rounded] || 0) + 1;
    }
    let bestBpm = null, bestCount = 0;
    for (const [bpm, count] of Object.entries(bpmVotes)) {
      if (count > bestCount) { bestCount = count; bestBpm = parseInt(bpm, 10); }
    }
    const confidence = bestCount / Math.max(1, peaks.length - 1);
    return { bpm: bestBpm, confidence, peakCount: peaks.length };
  } catch (err) {
    console.error('BPM detection failed', err);
    return null;
  }
}

/* ============ タイムストレッチ (WSOLA: ピッチを変えずにテンポだけ変更) ============ */

async function timeStretchBuffer(buffer, stretchRatio, onProgress) {
  // stretchRatio = 出力長 / 入力長 (>1で長く=遅く, <1で短く=速く)
  const ctx = getAudioCtx();
  const numChannels = buffer.numberOfChannels;
  const sr = buffer.sampleRate;
  const inputLength = buffer.length;
  const outputLength = Math.max(1, Math.round(inputLength * stretchRatio));

  // フレームを大きめ(93ms)+高オーバーラップ(75%)にして低音の周期性を捉えやすくする
  const frameSize = 4096;
  const synthesisHop = 1024;
  const analysisHopIdeal = synthesisHop / stretchRatio;
  const searchRadius = 384;
  const searchStep = 4;
  const overlapLen = frameSize - synthesisHop;

  const window_ = new Float32Array(frameSize);
  for (let i = 0; i < frameSize; i++) window_[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (frameSize - 1));

  const channelInputs = [];
  for (let ch = 0; ch < numChannels; ch++) channelInputs.push(buffer.getChannelData(ch));

  // 相関探索は全チャンネル共通のモノラル参照で1回だけ行う。
  // これによりL/Rが別々の位置にズレて位相が崩れる(=音像がぼやける)問題を防ぐ。
  const monoInput = new Float32Array(inputLength);
  for (let ch = 0; ch < numChannels; ch++) {
    const data = channelInputs[ch];
    for (let i = 0; i < inputLength; i++) monoInput[i] += data[i] / numChannels;
  }

  const outputs = [];
  for (let ch = 0; ch < numChannels; ch++) outputs.push(new Float32Array(outputLength + frameSize));
  const weightSum = new Float32Array(outputLength + frameSize); // 窓は全ch共通なので1系統で足りる
  const monoSynth = new Float32Array(outputLength + frameSize);  // 探索専用のモノ合成参照

  let synthesisPos = 0, analysisPos = 0, frameCount = 0;

  while (synthesisPos < outputLength && analysisPos + frameSize < inputLength) {
    const searchCenter = Math.round(analysisPos);
    let bestOffset = 0;

    if (synthesisPos > 0) {
      let bestScore = -Infinity;
      for (let off = -searchRadius; off <= searchRadius; off += searchStep) {
        const candStart = searchCenter + off;
        if (candStart < 0 || candStart + overlapLen >= inputLength) continue;
        let score = 0;
        for (let k = 0; k < overlapLen; k += 2) {
          score += monoSynth[synthesisPos + k] * monoInput[candStart + k];
        }
        if (score > bestScore) { bestScore = score; bestOffset = off; }
      }
    }

    const frameStart = Math.max(0, searchCenter + bestOffset);
    const lim = Math.min(frameSize, inputLength - frameStart, outputs[0].length - synthesisPos);

    for (let i = 0; i < lim; i++) {
      const w = window_[i];
      const outIdx = synthesisPos + i;
      let monoSample = 0;
      for (let ch = 0; ch < numChannels; ch++) {
        const s = channelInputs[ch][frameStart + i] * w;
        outputs[ch][outIdx] += s;
        monoSample += s;
      }
      weightSum[outIdx] += w;
      monoSynth[outIdx] += monoSample / numChannels;
    }

    synthesisPos += synthesisHop;
    analysisPos += analysisHopIdeal;
    frameCount++;
    if (frameCount % 80 === 0) {
      if (onProgress) onProgress(synthesisPos / outputLength);
      await new Promise(r => setTimeout(r, 0)); // UIをブロックしないようyield
    }
  }

  const outBuffer = ctx.createBuffer(numChannels, outputLength, sr);
  for (let ch = 0; ch < numChannels; ch++) {
    const out = outputs[ch];
    for (let i = 0; i < outputLength; i++) {
      if (weightSum[i] > 1e-6) out[i] /= weightSum[i];
    }
    outBuffer.copyToChannel(out.subarray(0, outputLength), ch);
  }

  return outBuffer;
}

/* ============ ボーカル除去/抽出 (STFTベースの中央定位マスキング) ============
   L/Rチャンネルを周波数ビンごとに比較し、"中央に定位している成分"(ボーカルであることが多い)を
   推定してマスクする。AIによる音源分離(Demucs等)とは全くの別物で、あくまで定位に基づく推定。
   モノラル音源には使えない(中央/サイドの区別自体が存在しないため)。 */

// 反復方式のCooley-Tukey FFT(2の冪乗長のみ対応)。invert=trueで逆変換(1/Nスケーリング込み)。
function fft(re, im, invert) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      let t = re[i]; re[i] = re[j]; re[j] = t;
      t = im[i]; im[i] = im[j]; im[j] = t;
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (invert ? 2 : -2) * Math.PI / len;
    const wRe = Math.cos(ang), wIm = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let curRe = 1, curIm = 0;
      for (let j = 0; j < len / 2; j++) {
        const uRe = re[i + j], uIm = im[i + j];
        const vRe = re[i + j + len / 2] * curRe - im[i + j + len / 2] * curIm;
        const vIm = re[i + j + len / 2] * curIm + im[i + j + len / 2] * curRe;
        re[i + j] = uRe + vRe; im[i + j] = uIm + vIm;
        re[i + j + len / 2] = uRe - vRe; im[i + j + len / 2] = uIm - vIm;
        const nextRe = curRe * wRe - curIm * wIm;
        const nextIm = curRe * wIm + curIm * wRe;
        curRe = nextRe; curIm = nextIm;
      }
    }
  }
  if (invert) {
    for (let i = 0; i < n; i++) { re[i] /= n; im[i] /= n; }
  }
}

async function processCenterChannel(buffer, mode, onProgress) {
  // mode: 'remove'(疑似カラオケ) | 'isolate'(疑似アカペラ)
  if (buffer.numberOfChannels < 2) {
    throw new Error('ステレオ音源にのみ使えます(モノラル音源には中央/サイドの区別が存在しません)');
  }
  const ctx = getAudioCtx();
  const sr = buffer.sampleRate;
  const L = buffer.getChannelData(0);
  const R = buffer.getChannelData(1);
  const len = buffer.length;

  const fftSize = 4096;
  const hop = fftSize / 2; // 50%オーバーラップ。周期的ハン窓なら w(n)+w(n+hop)=1 で完全再構成できる
  const window_ = new Float32Array(fftSize);
  for (let i = 0; i < fftSize; i++) window_[i] = 0.5 * (1 - Math.cos((2 * Math.PI * i) / fftSize));

  const outL = new Float32Array(len + fftSize);
  const outR = new Float32Array(len + fftSize);
  const reL = new Float32Array(fftSize), imL = new Float32Array(fftSize);
  const reR = new Float32Array(fftSize), imR = new Float32Array(fftSize);

  let frameCount = 0;
  for (let pos = 0; pos < len; pos += hop) {
    for (let i = 0; i < fftSize; i++) {
      const idx = pos + i;
      const inRange = idx < len;
      reL[i] = inRange ? L[idx] * window_[i] : 0;
      imL[i] = 0;
      reR[i] = inRange ? R[idx] * window_[i] : 0;
      imR[i] = 0;
    }
    fft(reL, imL, false);
    fft(reR, imR, false);

    for (let k = 0; k < fftSize; k++) {
      const midRe = (reL[k] + reR[k]) / 2, midIm = (imL[k] + imR[k]) / 2;
      const sideRe = (reL[k] - reR[k]) / 2, sideIm = (imL[k] - imR[k]) / 2;
      const midMag = Math.hypot(midRe, midIm);
      const sideMag = Math.hypot(sideRe, sideIm);
      const centerRatio = midMag / (midMag + sideMag + 1e-9); // 1に近いほど中央定位

      let gainMid, keepSide;
      if (mode === 'remove') {
        gainMid = 1 - Math.min(1, centerRatio * 1.6); // 中央成分を減衰
        keepSide = true;
      } else {
        gainMid = Math.min(1, Math.max(0, (centerRatio - 0.3) / 0.5)); // 中央成分だけ残す
        keepSide = false;
      }

      const newMidRe = midRe * gainMid, newMidIm = midIm * gainMid;
      const useSideRe = keepSide ? sideRe : 0;
      const useSideIm = keepSide ? sideIm : 0;

      reL[k] = newMidRe + useSideRe; imL[k] = newMidIm + useSideIm;
      reR[k] = newMidRe - useSideRe; imR[k] = newMidIm - useSideIm;
    }

    fft(reL, imL, true);
    fft(reR, imR, true);

    for (let i = 0; i < fftSize; i++) {
      const idx = pos + i;
      if (idx >= outL.length) break;
      // 合成側では窓を掛け直さない(解析窓のCOLA性質: w(n)+w(n+hop)=1 だけで正しく再構成される)
      outL[idx] += reL[i];
      outR[idx] += reR[i];
    }

    frameCount++;
    if (frameCount % 40 === 0) {
      if (onProgress) onProgress(Math.min(1, pos / len));
      await new Promise(r => setTimeout(r, 0));
    }
  }

  const outBuffer = ctx.createBuffer(2, len, sr);
  outBuffer.copyToChannel(outL.subarray(0, len), 0);
  outBuffer.copyToChannel(outR.subarray(0, len), 1);
  return outBuffer;
}

async function applyVocalProcess(clip, mode) {
  const buffer = getClipBuffer(clip);
  if (!buffer) return;
  if (buffer.numberOfChannels < 2) {
    alert('この処理はステレオ音源にのみ使えます。モノラル音源には中央/サイドの区別が存在しないため不可能です。');
    return;
  }
  const label = mode === 'remove' ? 'ボーカル除去(疑似カラオケ)' : 'ボーカル抽出(疑似アカペラ)';
  const baseId = clip.playSourceId || clip.sourceId;
  const cacheKey = `${baseId}__vocal_${mode}`;

  if (!audioBufferCache[cacheKey]) {
    setStatus(`${label}処理中: ${clip.fileName}...`);
    try {
      const processed = await processCenterChannel(buffer, mode, (p) => {
        setStatus(`${label}処理中: ${clip.fileName}... ${Math.round(p * 100)}%`);
      });
      audioBufferCache[cacheKey] = processed;
    } catch (err) {
      alert(err.message);
      setStatus(`⚠ ${label}に失敗: ${err.message}`);
      return;
    }
  }

  if (!clip.vocalMode) clip.preVocalSourceId = baseId; // 初回のみ処理前の状態を記録(元に戻す用)
  pushUndo();
  clip.playSourceId = cacheKey;
  clip.vocalMode = mode;
  renderAll();
  setStatus(`${label}完了: ${clip.fileName}(定位に基づく推定処理。曲によって効き目に差が出る)`);
}

function revertVocalProcess(clip) {
  if (!clip.vocalMode) return;
  pushUndo();
  clip.playSourceId = clip.preVocalSourceId || clip.sourceId;
  clip.vocalMode = null;
  clip.preVocalSourceId = null;
  renderAll();
  setStatus(`「${clip.fileName}」のボーカル処理を元に戻しました。`);
}

async function applyBpmStretch(clip, targetBpm) {
  if (!clip.detectedBpm) {
    alert('この音源は元BPMが未確定です。先に右クリック→「元BPMを手動設定」で設定してください。');
    return;
  }
  targetBpm = Math.max(40, Math.min(300, targetBpm));
  const stretchRatio = clip.detectedBpm / targetBpm; // 目標が速い(大きい)ほど出力は短くなる

  const cacheKey = Math.abs(stretchRatio - 1) < 0.002
    ? clip.sourceId
    : `${clip.sourceId}__bpm${targetBpm.toFixed(2)}`;

  if (!audioBufferCache[cacheKey]) {
    setStatus(`BPM変更処理中 (${clip.fileName}: ${clip.detectedBpm}→${targetBpm})...`);
    const original = audioBufferCache[clip.sourceId];
    const stretched = await timeStretchBuffer(original, stretchRatio, (p) => {
      setStatus(`BPM変更処理中 (${clip.fileName})... ${Math.round(p * 100)}%`);
    });
    audioBufferCache[cacheKey] = stretched;
  }

  pushUndo();
  clip.playSourceId = cacheKey;
  clip.targetBpm = targetBpm;
  clip.sourceDuration = audioBufferCache[cacheKey].duration;
  // BPM変更でバッファ長が変わるためトリムはリセット(全長を使う状態に戻す)
  clip.offset = 0;
  clip.duration = clip.sourceDuration;

  renderAll();
  setStatus(`BPM変更完了: ${clip.fileName} → ${targetBpm}BPM (ピッチはそのまま)`);
}

/* ============ 初期化 / イベント配線 ============ */

function initEvents() {
  document.getElementById('btnImport').addEventListener('click', handleImport);
  document.getElementById('btnAddEmptyTrack').addEventListener('click', addEmptyTrack);
  document.getElementById('btnNarration').addEventListener('click', () => openNarrationPanel());
  document.getElementById('btnRewind').addEventListener('click', () => seekTo(0));
  document.getElementById('btnPlay').addEventListener('click', togglePlay);
  document.getElementById('btnStop').addEventListener('click', stopPlayback);
  document.getElementById('btnExport').addEventListener('click', handleExport);
  document.getElementById('btnExportSplit').addEventListener('click', handleExportTrackSplit);
  document.getElementById('btnSaveProject').addEventListener('click', handleSaveProject);
  document.getElementById('btnLoadProject').addEventListener('click', handleLoadProject);
  document.getElementById('chkSnap').addEventListener('change', (e) => { state.snap = e.target.checked; });

  document.getElementById('zoomIn').addEventListener('click', () => {
    state.pxPerSec = Math.min(400, state.pxPerSec * 1.25);
    renderAll();
  });
  document.getElementById('zoomOut').addEventListener('click', () => {
    state.pxPerSec = Math.max(3, state.pxPerSec / 1.25);
    renderAll();
  });

  document.addEventListener('keydown', (e) => {
    if (e.code === 'Space' && e.target.tagName !== 'INPUT') {
      e.preventDefault();
      togglePlay();
    }
    if (e.key === 'Home' && e.target.tagName !== 'INPUT') {
      e.preventDefault();
      seekTo(0);
    }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 't') {
      e.preventDefault();
      if (state.selectedClipIds.size === 0) { setStatus('分割したいクリップを選択してください。'); return; }
      const playhead = getCurrentTimelinePosition();
      const entries = getSelectedClipEntries();
      pushUndo();
      let splitCount = 0;
      entries.forEach(({ track, clip }) => {
        if (playhead > clip.start + 0.08 && playhead < clip.start + clip.duration - 0.08) {
          splitClipAt(track, clip, playhead, { skipUndo: true });
          splitCount++;
        }
      });
      setStatus(splitCount > 0 ? `${splitCount}件のクリップを再生位置で分割しました。` : '再生位置がクリップの範囲内にありません。');
    }
    if (e.key === 'Delete' || e.key === 'Backspace') {
      if (state.selectedClipIds.size > 0 && e.target.tagName !== 'INPUT') {
        deleteSelectedClips();
      }
    }
    if ((e.metaKey || e.ctrlKey) && !e.shiftKey && e.key.toLowerCase() === 'z' && e.target.tagName !== 'INPUT') {
      e.preventDefault();
      undo();
    }
    if ((e.metaKey || e.ctrlKey) && (e.key.toLowerCase() === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z')) && e.target.tagName !== 'INPUT') {
      e.preventDefault();
      redo();
    }
  });

  // 再生中でなくてもタイムライン上のスクロールに合わせてplayheadは position:absolute のため追従不要
  setInterval(() => { if (!state.isPlaying) updateTimeDisplay(); }, 500);

  initPinchZoom();
  initDragDrop();
  initScrollSync();
  initLaneSeek();
  initTrackReorder();
}

// トラックヘッダーのグリップ(⠿)をドラッグして、トラックの上下の順番を入れ替える
function initTrackReorder() {
  const container = document.getElementById('trackHeaders');
  container.addEventListener('mousedown', (e) => {
    const grip = e.target.closest('.track-grip');
    if (!grip) return;
    e.preventDefault();
    const trackId = grip.dataset.track;
    const startIndex = state.tracks.findIndex(t => t.id === trackId);
    if (startIndex === -1) return;

    const draggedEl = grip.closest('.track-header');
    const startY = e.clientY;
    draggedEl.classList.add('dragging-track');

    const onMove = (ev) => {
      draggedEl.style.transform = `translateY(${ev.clientY - startY}px)`;
    };
    const onUp = (ev) => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      draggedEl.style.transform = '';
      draggedEl.classList.remove('dragging-track');

      const rowHeight = draggedEl.getBoundingClientRect().height || TRACK_LANE_HEIGHT;
      const shift = Math.round((ev.clientY - startY) / rowHeight);
      const newIndex = Math.max(0, Math.min(state.tracks.length - 1, startIndex + shift));
      if (newIndex !== startIndex) {
        pushUndo();
        const [moved] = state.tracks.splice(startIndex, 1);
        state.tracks.splice(newIndex, 0, moved);
        renderAll();
        setStatus(`「${moved.name}」の順番を変更しました。`);
      }
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
}

// トラックヘッダー(左)とタイムライン(右)のスクロールがズレる(「分離する」)問題の修正。
// ヘッダー側は自前でスクロールさせず、タイムライン側の縦スクロール位置に常に追従させる。
function initScrollSync() {
  const headers = document.getElementById('trackHeaders');
  const timeline = document.getElementById('timelineScroll');
  timeline.addEventListener('scroll', () => {
    headers.scrollTop = timeline.scrollTop;
  });
  // ヘッダー側にマウスホイールを当てても(overflow-y:hiddenで自分ではスクロールできないため)
  // タイムライン側へスクロール量を転送する
  headers.addEventListener('wheel', (e) => {
    timeline.scrollTop += e.deltaY;
    e.preventDefault();
  }, { passive: false });
}

// どのトラックのレーンをクリックしても、その位置に頭出し(シーク)できるようにする。
// クリップ本体やオートメーションの点/線のクリックは各要素側でstopPropagation済みなのでここには来ない。
// どのトラックのレーンをクリックしても頭出し(シーク)できる。
// 一定距離以上ドラッグした場合はシークの代わりにマーキー(矩形)選択になり、
// 矩形と交差する全クリップをまとめて選択できる(Shiftキーで既存選択に追加)。
function initLaneSeek() {
  const container = document.getElementById('tracksContainer');
  const DRAG_THRESHOLD = 4; // px。これ未満の移動はただのクリック(シーク)として扱う

  container.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return; // 左クリックのみ
    if (e.target.closest('.automation-overlay')) return; // オートメーション編集と競合させない
    if (e.target.closest('.clip')) return; // クリップ本体のドラッグは別のハンドラが処理する

    const startX = e.clientX, startY = e.clientY;
    const containerRect = container.getBoundingClientRect();
    let marqueeEl = null;
    let isDragging = false;

    const onMove = (ev) => {
      const dx = ev.clientX - startX, dy = ev.clientY - startY;
      if (!isDragging && Math.hypot(dx, dy) > DRAG_THRESHOLD) {
        isDragging = true;
        marqueeEl = document.createElement('div');
        marqueeEl.className = 'marquee-select';
        container.appendChild(marqueeEl);
      }
      if (isDragging) {
        const x1 = Math.min(startX, ev.clientX), x2 = Math.max(startX, ev.clientX);
        const y1 = Math.min(startY, ev.clientY), y2 = Math.max(startY, ev.clientY);
        marqueeEl.style.left = (x1 - containerRect.left) + 'px';
        marqueeEl.style.top = (y1 - containerRect.top) + 'px';
        marqueeEl.style.width = (x2 - x1) + 'px';
        marqueeEl.style.height = (y2 - y1) + 'px';
      }
    };

    const onUp = (ev) => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);

      if (isDragging) {
        const selRect = marqueeEl.getBoundingClientRect();
        const hitIds = [];
        document.querySelectorAll('.clip').forEach(clipEl => {
          const r = clipEl.getBoundingClientRect();
          const intersects = !(r.right < selRect.left || r.left > selRect.right || r.bottom < selRect.top || r.top > selRect.bottom);
          if (intersects) hitIds.push(clipEl.dataset.clip);
        });
        if (!ev.shiftKey) state.selectedClipIds.clear();
        hitIds.forEach(id => state.selectedClipIds.add(id));
        document.querySelectorAll('.clip').forEach(el => {
          el.classList.toggle('selected', state.selectedClipIds.has(el.dataset.clip));
        });
        marqueeEl.remove();
        suppressNextDeselect = true; // 直後に発火するclickイベントで選択を消させない
        setStatus(hitIds.length > 0 ? `${hitIds.length}件のクリップを選択しました。` : '選択範囲にクリップがありませんでした。');
      } else {
        if (e.target.closest('.automation-overlay')) return;
        const lane = e.target.closest('.track-lane');
        if (!lane) return;
        const rect = lane.getBoundingClientRect();
        const t = (e.clientX - rect.left) / state.pxPerSec;
        seekTo(Math.max(0, t));
      }
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
}

// トラックパッドの「つまむ」操作はChromium/Electronでは ctrlKey付きの wheel イベントとして届く。
// これを利用してカーソル位置を基準にズームイン/アウトする(つまむ→縮小、広げる→拡大の両方向に対応)。
function initPinchZoom() {
  const scrollEl = document.getElementById('timelineScroll');
  scrollEl.addEventListener('wheel', (e) => {
    if (!e.ctrlKey) return; // 通常のスクロールはそのまま
    e.preventDefault();
    const rect = scrollEl.getBoundingClientRect();
    const cursorX = e.clientX - rect.left + scrollEl.scrollLeft;
    const timeAtCursor = cursorX / state.pxPerSec;

    const zoomFactor = Math.exp(-e.deltaY * 0.012);
    state.pxPerSec = Math.max(3, Math.min(400, state.pxPerSec * zoomFactor));
    renderAll();

    requestAnimationFrame(() => {
      scrollEl.scrollLeft = timeAtCursor * state.pxPerSec - (e.clientX - rect.left);
    });
  }, { passive: false });
}

initEvents();
renderAll();
setStatus('音源を追加してタイムラインに配置してください。ファイルをウィンドウにドラッグ&ドロップしても追加できる。');
