const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  importAudioFiles: () => ipcRenderer.invoke('import-audio-files'),
  exportWav: (payload) => ipcRenderer.invoke('export-wav', payload),
  exportTrackSplit: (payload) => ipcRenderer.invoke('export-track-split', payload),
  listNarrationVoices: () => ipcRenderer.invoke('list-narration-voices'),
  synthesizeNarration: (payload) => ipcRenderer.invoke('synthesize-narration', payload),
  saveProject: (payload) => ipcRenderer.invoke('save-project', payload),
  loadProject: () => ipcRenderer.invoke('load-project'),
});
