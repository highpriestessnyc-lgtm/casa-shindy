const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execFile } = require('child_process');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#0b0b0d',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile('index.html');
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// 音声ファイルを複数選択してインポート
ipcMain.handle('import-audio-files', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '音声ファイルをインポート',
    properties: ['openFile', 'multiSelections'],
    filters: [
      { name: 'Audio', extensions: ['mp3', 'wav', 'aac', 'm4a', 'ogg', 'flac'] },
    ],
  });
  if (result.canceled) return [];
  return result.filePaths.map((filePath) => {
    const buffer = fs.readFileSync(filePath);
    return {
      filePath,
      fileName: path.basename(filePath),
      base64: buffer.toString('base64'),
      ext: path.extname(filePath).replace('.', ''),
    };
  });
});

// ミックスダウンしたWAVを保存
ipcMain.handle('export-wav', async (event, { defaultName, arrayBuffer }) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'ミックスを書き出し',
    defaultPath: defaultName || 'mixdown.wav',
    filters: [{ name: 'WAV Audio', extensions: ['wav'] }],
  });
  if (result.canceled || !result.filePath) return { ok: false };
  fs.writeFileSync(result.filePath, Buffer.from(arrayBuffer));
  return { ok: true, filePath: result.filePath };
});

// プロジェクト保存
ipcMain.handle('save-project', async (event, { defaultName, json }) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'プロジェクトを保存',
    defaultPath: defaultName || 'project.bgmmix.json',
    filters: [{ name: 'BGM MIX Project', extensions: ['json'] }],
  });
  if (result.canceled || !result.filePath) return { ok: false };
  fs.writeFileSync(result.filePath, json, 'utf-8');
  return { ok: true, filePath: result.filePath };
});

// トラック分割書き出し: フォルダを選択し、個別WAV + CUEシートをまとめて保存
ipcMain.handle('export-track-split', async (event, { defaultFolderName, files }) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '書き出し先フォルダを選択',
    properties: ['openDirectory', 'createDirectory'],
  });
  if (result.canceled || result.filePaths.length === 0) return { ok: false };

  const baseDir = result.filePaths[0];
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const outDir = path.join(baseDir, `${defaultFolderName || 'export'}_${stamp}`);
  fs.mkdirSync(outDir, { recursive: true });

  for (const f of files) {
    const filePath = path.join(outDir, f.name);
    if (f.kind === 'wav') {
      fs.writeFileSync(filePath, Buffer.from(f.arrayBuffer));
    } else if (f.kind === 'text') {
      fs.writeFileSync(filePath, f.text, 'utf-8');
    }
  }
  return { ok: true, folderPath: outDir };
});

// プロジェクト読込
ipcMain.handle('load-project', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'プロジェクトを開く',
    properties: ['openFile'],
    filters: [{ name: 'BGM MIX Project', extensions: ['json'] }],
  });
  if (result.canceled || result.filePaths.length === 0) return { ok: false };
  const json = fs.readFileSync(result.filePaths[0], 'utf-8');
  const project = JSON.parse(json);
  // プロジェクト内で参照している音声ファイルを再読込
  const missing = [];
  for (const track of project.tracks || []) {
    for (const clip of track.clips || []) {
      try {
        const buffer = fs.readFileSync(clip.filePath);
        clip.base64 = buffer.toString('base64');
        clip.ext = path.extname(clip.filePath).replace('.', '');
      } catch (e) {
        missing.push(clip.filePath);
      }
    }
  }
  return { ok: true, project, missing };
});

/* ============ ナレーション (macOS標準 say コマンド) ============ */

// インストール済みの音声一覧を取得 (`say -v ?` の出力をパース)
ipcMain.handle('list-narration-voices', async () => {
  return new Promise((resolve) => {
    execFile('say', ['-v', '?'], (err, stdout) => {
      if (err) { resolve({ ok: false, voices: [], error: err.message }); return; }
      const voices = stdout
        .split('\n')
        .map(line => line.match(/^(\S+)\s+(\S+)\s+#/))
        .filter(Boolean)
        .map(m => ({ name: m[1], locale: m[2] }));
      resolve({ ok: true, voices });
    });
  });
});

// テキストを音声合成してWAVファイルとして書き出す。
// --file-format/--data-format を明示してPCM WAVで出力する
// (Web Audio の decodeAudioData がAIFF等を確実にデコードできる保証が無いため)。
ipcMain.handle('synthesize-narration', async (event, { text, voice, rate }) => {
  if (!text || !text.trim()) return { ok: false, error: 'テキストが空です' };
  const outPath = path.join(os.tmpdir(), `bgm_narration_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.wav`);
  const args = [];
  if (voice) args.push('-v', voice);
  if (rate) args.push('-r', String(rate));
  args.push('--file-format=WAVE', '--data-format=LEI16@44100', '-o', outPath, text);

  return new Promise((resolve) => {
    execFile('say', args, (err) => {
      if (err) {
        const hint = err.code === 'ENOENT'
          ? 'sayコマンドが見つかりません(macOS専用機能です)'
          : err.message;
        resolve({ ok: false, error: hint });
        return;
      }
      try {
        const buffer = fs.readFileSync(outPath);
        resolve({ ok: true, filePath: outPath, base64: buffer.toString('base64') });
      } catch (e) {
        resolve({ ok: false, error: e.message });
      }
    });
  });
});
